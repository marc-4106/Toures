// score.js
import haversine from "../../../recommender/distance";
import { INTEREST_TAG_ALIASES } from "./interestAliases.js";

/* -------------------------------------------
 * Utility: Distance calculation (km)
 * ------------------------------------------*/
export const kmFromStart = (place, start) => {
  if (!place?.lat || !place?.lng || !start?.lat || !start?.lng) return 9999;
  try {
    const a = { latitude: Number(start.lat), longitude: Number(start.lng) };
    const b = { latitude: Number(place.lat), longitude: Number(place.lng) };
    const dist = haversine(a, b) / 1000;
    return Number.isFinite(dist) ? dist : 9999;
  } catch (err) {
    console.warn("Distance calc error:", err);
    return 9999;
  }
};

/* -------------------------------------------
 * Fuzzy membership functions
 * ------------------------------------------*/

const triangular = (x, a, b, c) => {
  if (x <= a || x >= c) return 0;
  if (x === b) return 1;
  if (x > a && x < b) return (x - a) / (b - a);
  return (c - x) / (c - b);
};

const trapezoid = (x, a, b, c, d) => {
  if (x <= a || x >= d) return 0;
  if (x >= b && x <= c) return 1;
  if (x > a && x < b) return (x - a) / (b - a);
  return (d - x) / (d - c);
};

/* -------------------------------------------
 * Enhanced Interest Fuzzy Fit
 * ------------------------------------------*/
export const interestFit = (tags = [], interests = []) => {
  if (!tags.length || !interests.length) return 0;

  const normalize = (v) => v.toLowerCase().replace(/[\s_]/g, "");

  const normalizedTags = tags.map(normalize);
  const expandedInterests = new Set();

  // Expand user interests using aliases
  for (const interest of interests) {
    const key = normalize(interest);
    expandedInterests.add(key);

    // Include alias mappings if present
    const aliases = INTEREST_TAG_ALIASES[key] || [];
    aliases.forEach((a) => expandedInterests.add(normalize(a)));
  }

  const interestPool = Array.from(expandedInterests);
  if (interestPool.length === 0) return 0;

  let matchCount = 0;
  for (const tag of normalizedTags) {
    const exact = interestPool.includes(tag);
    const partial = interestPool.some(
      (i) => tag.includes(i) || i.includes(tag)
    );
    matchCount += exact ? 1 : partial ? 0.6 : 0;
  }

  // Normalized fuzzy match
  const baseScore = matchCount / Math.sqrt(normalizedTags.length || 1);
  return Math.min(trapezoid(baseScore, 0.2, 0.6, 1.0, 1.3), 1);
};

/* -------------------------------------------
 * Core Fuzzy Score Computation
 * ------------------------------------------*/
export const fuzzyScore = (place, preferences) => {
  const start = preferences?.startCity || {};
  const maxBudget = Number(preferences?.maxBudget || 0);
  const interests = preferences?.interests || [];
  const priority = preferences?.priority || "interest";
  const travelerType = (preferences?.travelType || "any").toLowerCase();
  const lodgingPref = (preferences?.lodgingPreference || "any").toLowerCase();

  const distanceKm = kmFromStart(place, start);
  const price = Number(place.price || 0);
  const iFit = interestFit(place.tags, interests);

  // Fuzzy memberships
  const distMembership = trapezoid(distanceKm, 0, 10, 40, 80);
 
  let priceMembership = 1;
  if (maxBudget > 0 && price > 0) {
    if (price <= maxBudget) {
      // Perfect fit (cheap enough)
      priceMembership = trapezoid(price, 0, maxBudget * 0.3, maxBudget * 0.7, maxBudget);
    } else if (price <= maxBudget * 2) {
      // Slightly above budget — small penalty but not zero
      priceMembership = trapezoid(price, maxBudget, maxBudget * 1.3, maxBudget * 1.7, maxBudget * 2);
    } else {
      priceMembership = 0.1; // Very expensive, but not zero (allow rare exceptions)
    }
  }

  const interestMembership = iFit;

  // Base weights
  let wInterest = 0.5;
  let wDistance = 0.3;
  let wPrice = 0.2;
  let kindMatchMultiplier = 1.0;

  const kind = String(place.kind || "").toLowerCase().trim();

  // Lodging adjustment
  if (kind.includes("hotel") || kind.includes("resort") || kind.includes("inn")) {
    wInterest = 0.25;
    wDistance = 0.35;
    wPrice = 0.4;

    if (lodgingPref !== "any") {
      if (kind.includes(lodgingPref)) kindMatchMultiplier *= 1.5;
      else kindMatchMultiplier *= 0.8;
    }
  }

  // Traveler type impact
  if (travelerType === "family" || travelerType === "group") {
    if (place.tags.some((t) => t.toLowerCase().includes("family")))
      kindMatchMultiplier *= 1.2;
  } else if (travelerType === "couple") {
    if (place.tags.some((t) => t.toLowerCase().includes("romantic")))
      kindMatchMultiplier *= 1.2;
  }

  // Apply priority boosts
  const boosts = { interest: 0.3, distance: 0.3, price: 0.3 };
  if (priority === "interest") wInterest *= 1 + boosts.interest;
  if (priority === "distance") wDistance *= 1 + boosts.distance;
  if (priority === "price" || priority === "budget") wPrice *= 1 + boosts.price;

  // Normalize
  const sum = wInterest + wDistance + wPrice;
  wInterest /= sum;
  wDistance /= sum;
  wPrice /= sum;

  // Combine fuzzy scores
  const score =
    (wInterest * interestMembership +
      wDistance * distMembership +
      wPrice * priceMembership) *
    kindMatchMultiplier;

  return Math.min(1, Math.max(0, score));
};

/* -------------------------------------------
 * Rank destinations by fuzzy logic
 * ------------------------------------------*/
export const rankDestinations = (places, preferences) =>
  places
    .map((place) => {
      const score = fuzzyScore(place, preferences);
      const distance = kmFromStart(place, preferences?.startCity);
      const iFit = interestFit(place.tags, preferences?.interests || []);
      return {
        ...place,
        dKm: distance,
        iFit,
        score,
      };
    })
    .sort((a, b) => b.score - a.score);
