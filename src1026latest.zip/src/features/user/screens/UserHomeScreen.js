// src/features/user/screens/UserHomeScreen.js
import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

import { useDestinations } from "../hooks/useDestinations";
import DestinationCard from "../components/DestinationCard";
import DestinationDetailsModal from "../components/DestinationDetailsModal";
import { haversineKm } from "../../recommender/distance";

const KIND_CHIPS = [
  "All (10 km)",
  "Featured",
  "Hotel",
  "Restaurant",
  "Resort",
  "Mall",
  "Heritage",
  "Pasalubong Centers",
];

const MAX_FEATURED_RADIUS_KM = 50;
const NEARBY_RADIUS_KM = 10;

export default function UserHomeScreen() {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();

  const { destinations, isLoading, errorMsg } = useDestinations();

  // 🔵 user location
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") return;
        const pos = await Location.getCurrentPositionAsync({});
        setUserLocation({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
      } catch {}
    })();
  }, []);

  // --- search & chips ---
  const [search, setSearch] = useState("");
  const [selectedChip, setSelectedChip] = useState("Featured");

  // 🎠 Featured carousel (within 50km)
  const featuredNearby = useMemo(() => {
    if (!userLocation) return [];
    return destinations
      .filter((d) => d.isFeatured === true && d.imageUrl)
      .filter((d) => {
        const lat = d?.Coordinates?.latitude;
        const lng = d?.Coordinates?.longitude;
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
        const km = haversineKm(userLocation.latitude, userLocation.longitude, lat, lng);
        return km <= MAX_FEATURED_RADIUS_KM;
      });
  }, [destinations, userLocation]);

  // 📋 Main list
  const filtered = useMemo(() => {
    const q = (search || "").toLowerCase().trim();

    // 🔎 Search overrides distance filters: name + kind + tags
    if (q.length > 0) {
      return destinations.filter((d) => {
        const inName = (d.name || "").toLowerCase().includes(q);
        const inKind = (d.kind || "").toLowerCase().includes(q);
        const inTags = (Array.isArray(d.tags) ? d.tags : []).join(" ").toLowerCase().includes(q);
        return inName || inKind || inTags;
      });
    }

    // No search → chip logic
    if (selectedChip === "Featured") {
      if (!userLocation) return [];
      return destinations.filter((d) => {
        if (d.isFeatured !== true) return false;
        const lat = d?.Coordinates?.latitude;
        const lng = d?.Coordinates?.longitude;
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
        const km = haversineKm(userLocation.latitude, userLocation.longitude, lat, lng);
        return km <= MAX_FEATURED_RADIUS_KM;
      });
    }

    if (selectedChip === "All (10 km)") {
      if (!userLocation) return [];
      return destinations.filter((d) => {
        const lat = d?.Coordinates?.latitude;
        const lng = d?.Coordinates?.longitude;
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
        const km = haversineKm(userLocation.latitude, userLocation.longitude, lat, lng);
        return km <= NEARBY_RADIUS_KM;
      });
    }

    // Kinds (no distance restriction)
    const kindKey = selectedChip.toLowerCase();
    return destinations.filter((d) => (d.kind || "") === kindKey);
  }, [destinations, search, selectedChip, userLocation]);

  // 🔎 Details modal state
  const [selected, setSelected] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const openDetails = (item) => {
    setSelected(item);
    setModalVisible(true);
  };

  // Loading / error
  if (isLoading) {
    return (
      <SafeAreaView style={[styles.container, { paddingTop: insets.top }]}>
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <ActivityIndicator size="large" color="#0f37f1" />
        </View>
      </SafeAreaView>
    );
  }
  if (errorMsg) {
    return (
      <SafeAreaView style={[styles.container, { paddingTop: insets.top }]}>
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <Text style={{ color: "red" }}>{errorMsg}</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.headerRow}>
        <View style={styles.brandRow}>
          <Image
            source={require("../../../../assets/login/WhiteToures.png")}
            style={styles.brandLogo}
            resizeMode="contain"
          />
          <Text style={styles.title}>Toures</Text>
        </View>
        <TouchableOpacity style={styles.iconBtn}>
          <Ionicons name="notifications-outline" size={24} color="#0f172a" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#64748b" style={{ marginHorizontal: 8 }} />
        <TextInput
          placeholder="Search by name, kind, tags…"
          placeholderTextColor="#94a3b8"
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* CTA */}
      <TouchableOpacity
        onPress={() => navigation.navigate("TravelPreferences")}
        style={styles.primaryCta}
      >
        <Ionicons name="bulb-outline" size={18} color="#fff" />
        <Text style={styles.primaryCtaText}>Start Fuzzy Plan</Text>
      </TouchableOpacity>

     

      {/* Chips */}
     
      <View style={styles.chipsRow}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsContent}>
          {KIND_CHIPS.map((item) => {
            const active = selectedChip === item;
            return (
              <TouchableOpacity
                key={item}
                style={[styles.chipFixed, active ? styles.chipActive : styles.chipInactive]}
                onPress={() => setSelectedChip(item)}
                activeOpacity={0.85}
              >
                <Text style={[styles.chipTextFixed, active ? { color: "#0f37f1" } : { color: "#0f172a" }]} numberOfLines={1}>
                  {item}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {/* List */}
      <FlatList
        data={filtered.map((x) => ({ ...x, __nav: navigation }))} // attach nav for the card "Get Direction"
        keyExtractor={(it) => it.id}
        renderItem={({ item }) => (
          
          <DestinationCard item={item} userLocation={userLocation} onPress={openDetails} />
        )}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 65 }}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        ListEmptyComponent={
          selectedChip === "Featured" || selectedChip === "All (10 km)" ? (
            <Text style={{ color: "#6b7280", textAlign: "center", marginTop: 8 }}>
              {userLocation
                ? selectedChip === "Featured"
                  ? `No featured places within ${MAX_FEATURED_RADIUS_KM} km.`
                  : `No places within ${NEARBY_RADIUS_KM} km.`
                : "Turn on location to see nearby places."}
            </Text>
          ) : (
            <Text style={{ color: "#6b7280", textAlign: "center", marginTop: 8 }}>
              No places found for this category.
            </Text>
          )
        }
      />

      {/* Details Modal */}
      <DestinationDetailsModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        destination={selected}
        userLocation={userLocation}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fafc"},

  headerRow: {
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#f8fafc",
    zIndex: 2,
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  brandLogo: { width: 28, height: 28, borderRadius: 6 },
  title: { fontSize: 22, fontWeight: "900", color: "#0f172a" },
  iconBtn: {
    width: 36, height: 36, borderRadius: 18, backgroundColor: "#eef2ff",
    alignItems: "center", justifyContent: "center",
  },

  searchRow: {
    marginHorizontal: 16,
    marginBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 12, backgroundColor: "#fff",
  },
  searchInput: { flex: 1, height: 44, color: "#0f172a", paddingRight: 12 },

  primaryCta: {
    marginHorizontal: 16, marginBottom: 12,
    backgroundColor: "#0f37f1", borderRadius: 12,
    paddingVertical: 12, alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 8,
  },
  primaryCtaText: { color: "#fff", fontWeight: "800" },

  sectionHeader: { paddingHorizontal: 16, marginTop: 6, marginBottom: 8 },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: "#0f172a" },

  featureCard: {
    width: 220, height: 130, borderRadius: 12, overflow: "hidden", backgroundColor: "#e2e8f0", marginBottom: 6,
  },
  featureImage: { width: "100%", height: "100%" },
  featureCaption: { position: "absolute", left: 0, right: 0, bottom: 0, padding: 8, backgroundColor: "rgba(0,0,0,0.35)" },
  featureTitle: { color: "#fff", fontWeight: "800" },

  chipsRow: { height: 48, marginBottom: 8 },
  chipsContent: { paddingHorizontal: 16, alignItems: "center" },
  chipFixed: {
    height: 36, minWidth: 84, paddingHorizontal: 12,
    borderRadius: 999, borderWidth: 1, marginRight: 8,
    alignItems: "center", justifyContent: "center",
  },
  chipTextFixed: { fontWeight: "700", fontSize: 13 },
  chipActive: { backgroundColor: "#dbeafe", borderColor: "#93c5fd" },
  chipInactive: { backgroundColor: "#fff", borderColor: "#e2e8f0" },
});
