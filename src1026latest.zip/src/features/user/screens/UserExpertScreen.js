import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  Animated,
  TouchableWithoutFeedback,
  TouchableOpacity,
  Platform,
  ActivityIndicator,
  ScrollView,
  RefreshControl,
} from "react-native";
import { useNavigation, useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { collection, query, where, orderBy, getDocs } from "firebase/firestore";
import { db, auth } from "../../../services/firebaseConfig";

export default function UserExpertScreen() {
  const navigation = useNavigation();
  const scale = useRef(new Animated.Value(1)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [itineraries, setItineraries] = useState([]);

  const goToPreferences = () => navigation.navigate("TravelPreferences");

  const onPressIn = () =>
    Animated.spring(scale, { toValue: 0.9, useNativeDriver: true }).start();
  const onPressOut = () =>
    Animated.spring(scale, { toValue: 1, friction: 3, useNativeDriver: true }).start(() => {
      goToPreferences();
    });

  // Fetch all itineraries
  const fetchItineraries = useCallback(async () => {
    try {
      setLoading(true);
      const userId = auth?.currentUser?.uid || "guest";
      const q = query(
        collection(db, "itineraries"),
        where("userId", "==", userId),
        where("isArchived", "==", false),
        orderBy("createdAt", "desc")

      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        const trips = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setItineraries(trips);
      } else {
        setItineraries([]);
      }
    } catch (err) {
      console.warn("Failed to load itineraries:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

 

useFocusEffect(
  React.useCallback(() => {
    fetchItineraries();
  }, [fetchItineraries])
);


  const onRefresh = () => {
    setRefreshing(true);
    fetchItineraries();
  };

  const goToItinerary = (trip) => {
  navigation.navigate("ItineraryDetails", { itinerary: trip });
};


      const editItinerary = (trip) => {
  navigation.navigate("TravelPreferences", {
    mode: "edit",
    itineraryId: trip.id, // ✅ include the ID
    savedItinerary: {
      hotel: trip.hotel,
      days: trip.days,
      totals: trip.totals,
      preferences: trip.preferences,
    },
  });
};


  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Explore with Toures ✈️</Text>
      <Text style={styles.sub}>
        Plan your next adventure — or revisit your saved itineraries.
      </Text>

      {/* ========== ITINERARY LIST ========== */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 100 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={["#0f37f1"]} />
        }
      >
        {loading ? (
          <ActivityIndicator color="#0f37f1" style={{ marginTop: 30 }} />
        ) : itineraries.length > 0 ? (
          itineraries.map((trip, index) => (
            <View key={trip.id || index} style={styles.card}>
              <View style={styles.cardHeader}>
                <Ionicons name="sparkles-outline" size={20} color="#0f37f1" />
                <Text style={styles.cardTitle}>
                  {trip.name || trip.preferences?.startCity?.label || "Unnamed Itinerary"}
                </Text>

              </View>

              <View style={styles.tripDetails}>
                <View style={styles.detailRow}>
                  <Ionicons name="location-outline" size={16} color="#475569" />
                  <Text style={styles.detailText}>
                    Start City:{" "}
                    <Text style={styles.detailHighlight}>
                      {trip.preferences?.startCity?.label || "Unknown"}
                    </Text>
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <Ionicons name="calendar-outline" size={16} color="#475569" />
                  <Text style={styles.detailText}>
                    Dates:{" "}
                    <Text style={styles.detailHighlight}>
                      {new Date(trip.preferences?.startDate).toLocaleDateString()} -{" "}
                      {new Date(trip.preferences?.endDate).toLocaleDateString()}
                    </Text>
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <Ionicons name="cash-outline" size={16} color="#475569" />
                  <Text style={styles.detailText}>
                    Budget:{" "}
                    <Text style={styles.detailHighlight}>
                      ₱{trip.preferences?.maxBudget?.toLocaleString() || "0"}
                    </Text>
                  </Text>
                </View>

                <View style={styles.detailRow}>
                  <Ionicons name="star-outline" size={16} color="#475569" />
                  <Text style={styles.detailText}>
                    Priority:{" "}
                    <Text style={styles.detailHighlight}>
                      {trip.preferences?.priority || "Balanced"}
                    </Text>
                  </Text>
                </View>
              </View>

              <View style={styles.actionRow}>
                <TouchableOpacity
                  style={[styles.btn, styles.btnView]}
                  onPress={() => goToItinerary(trip)}
                >
                  <Ionicons name="eye-outline" size={16} color="#fff" />
                  <Text style={styles.btnText}>View</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.btn, styles.btnEdit]}
                  onPress={() => editItinerary(trip)}
                >
                  <Ionicons name="create-outline" size={16} color="#0f37f1" />
                  <Text style={[styles.btnText, { color: "#0f37f1" }]}>Edit</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        ) : (
          <View style={{ alignItems: "center", paddingVertical: 30 }}>
            <Ionicons name="alert-circle-outline" size={28} color="#94a3b8" />
            <Text style={{ color: "#475569", marginTop: 8 }}>
              You don’t have a saved itinerary yet.
            </Text>
            <Text style={{ color: "#64748b", fontSize: 12 }}>
              Tap the Toures icon to create one.
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Floating Start Button */}
      <Animated.View style={[styles.pinWrapper, { transform: [{ scale }] }]}>
        <TouchableWithoutFeedback onPressIn={onPressIn} onPressOut={onPressOut}>
          <View style={styles.buttonWrapper}>
            <View style={styles.shadowGlow} />
            <Image
              source={require("../../../../assets/login/WhiteToures.png")}
              style={styles.pinImage}
              resizeMode="contain"
            />
          </View>
        </TouchableWithoutFeedback>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8f9fa", padding: 16 },
  heading: { fontSize: 24, fontWeight: "800", color: "#0f172a", marginTop: 8 },
  sub: { marginTop: 6, color: "#475569", marginBottom: 16 },

  card: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 3,
    marginBottom: 12,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", marginBottom: 8 },
  cardTitle: { fontSize: 16, fontWeight: "700", marginLeft: 6, color: "#0f172a" },
  tripDetails: { marginVertical: 8 },
  detailRow: { flexDirection: "row", alignItems: "center", marginVertical: 3 },
  detailText: { fontSize: 14, color: "#334155", marginLeft: 6 },
  detailHighlight: { fontWeight: "600", color: "#0f37f1" },
  actionRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 12 },
  btn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  btnView: { backgroundColor: "#0f37f1", flex: 1, marginRight: 6, justifyContent: "center" },
  btnEdit: {
    backgroundColor: "#e0f2fe",
    flex: 1,
    marginLeft: 6,
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#0ea5e9",
  },
  btnText: { fontWeight: "700", color: "#fff", marginLeft: 6 },
  pinWrapper: {
    position: "absolute",
    right: 20,
    bottom: 60,
    width: 80,
    height: 80,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonWrapper: { alignItems: "center", justifyContent: "center" },
  shadowGlow: {
    position: "absolute",
    width: 65,
    height: 60,
    borderRadius: 45,
    backgroundColor: "rgba(15, 55, 241, 0.18)",
    ...Platform.select({
      ios: { shadowColor: "#0f37f1", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.4, shadowRadius: 10 },
      android: { elevation: 12 },
    }),
  },
  pinImage: { width: 60, height: 60 },
});
