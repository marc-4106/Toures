import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Platform,
  SafeAreaView,
  KeyboardAvoidingView,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "../../../services/firebaseConfig";
import { buildItinerary } from "../logic/fuzzy/itinerary";
import * as Location from "expo-location";
import { getItinerary } from "../logic/getItinerary";

// ========== INTEREST CATEGORIES ==========
const INTEREST_CATEGORIES = {
  food: {
    label: "Food & Dining",
    icon: "restaurant-outline",
    items: [
      { key: "local_cuisine", label: "Local Cuisine" },
      { key: "seafood", label: "Seafood" },
      { key: "buffet", label: "Buffet / Eat-All-You-Can" },
      { key: "fine_dining", label: "Fine Dining" },
      { key: "street_food", label: "Street Food" },
      { key: "cafes", label: "Cafés & Bakeries" },
    ],
  },
  accommodation: {
    label: "Accommodation & Lodging",
    icon: "bed-outline",
    items: [
      { key: "luxury", label: "Luxury" },
      { key: "budget", label: "Budget" },
      { key: "family_friendly", label: "Family Friendly" },
      { key: "romantic", label: "Romantic" },
      { key: "eco_resort", label: "Eco Resort" },
      { key: "beachfront", label: "Beachfront" },
      { key: "city_hotel", label: "City Hotel" },
      { key: "camping", label: "Camping" },
    ],
  },
  activities: {
    label: "Activities & Experiences",
    icon: "walk-outline",
    items: [
      { key: "adventure", label: "Adventure" },
      { key: "hiking", label: "Hiking" },
      { key: "diving", label: "Diving" },
      { key: "boating", label: "Boating" },
      { key: "culture", label: "Cultural" },
      { key: "heritage", label: "Heritage & History" },
      { key: "nature_tripping", label: "Nature Tripping" },
      { key: "photography", label: "Photography" },
      { key: "relaxation", label: "Relaxation / Spa" },
      { key: "spiritual", label: "Spiritual Retreats" },
    ],
  },
  environment: {
    label: "Destination Type",
    icon: "earth-outline",
    items: [
      { key: "beach", label: "Beach" },
      { key: "mountain", label: "Mountain" },
      { key: "island", label: "Island" },
      { key: "city", label: "City" },
      { key: "rural", label: "Countryside" },
      { key: "eco_park", label: "Eco Park" },
      { key: "farm", label: "Farm / Agri-tourism" },
      { key: "lake", label: "Lake" },
    ],
  },
  lifestyle: {
    label: "Lifestyle & Social",
    icon: "sparkles-outline",
    items: [
      { key: "nightlife", label: "Nightlife" },
      { key: "shopping", label: "Shopping" },
      { key: "arts", label: "Art & Crafts" },
      { key: "music", label: "Music Events" },
      { key: "romantic_spots", label: "Romantic Spots" },
      { key: "family_activities", label: "Family Activities" },
      { key: "local_market", label: "Local Market" },
      { key: "relaxing_cafes", label: "Relaxing Cafés" },
    ],
  },
};
// ==========================================

const formatDate = (d) =>
  new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(d);

const START_CITIES = [
  { label: "Bacolod", lat: 10.6767, lng: 122.9511 },
  { label: "Bago", lat: 10.5333, lng: 122.8333 },
  { label: "Kabankalan", lat: 9.9833, lng: 122.8167 },
  { label: "Silay", lat: 10.753, lng: 122.9674 },
  { label: "Sipalay", lat: 9.7513, lng: 122.4048 },
  { label: "Talisay", lat: 10.737, lng: 122.9671 },
  { label: "Victorias", lat: 10.9012, lng: 123.0701 },
];

export default function TravelPreferencesScreen() {
  const navigation = useNavigation();
  const route = useRoute();

  const [startCityIdx, setStartCityIdx] = useState(0);
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date(Date.now() + 86400000));
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd] = useState(false);
  const [maxBudget, setMaxBudget] = useState("");
  const [priority, setPriority] = useState("balanced");
  const [loading, setLoading] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState(new Set());
  const [expandedSections, setExpandedSections] = useState({});
  const [isEditing, setIsEditing] = useState(false);

  // 🔹 Toggle collapsible section
  const toggleSection = (key) => {
    setExpandedSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // 🔹 Toggle interest selection
  const toggleInterest = (key) => {
    setSelectedInterests((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  // 🔹 Load existing itinerary if in edit mode
  useEffect(() => {
    const loadExisting = async () => {
      if (route.params?.mode === "edit" && route.params?.itineraryId) {
        setIsEditing(true);
        const data = await getItinerary(route.params.itineraryId);
        if (!data) return;

        const prefs = data.preferences;
        if (!prefs) return;

        setMaxBudget(String(prefs.maxBudget || ""));
        setPriority(prefs.priority || "balanced");
        setSelectedInterests(new Set(prefs.interests || []));

        const idx = START_CITIES.findIndex(
          (c) => c.label === prefs.startCity?.label
        );
        if (idx !== -1) setStartCityIdx(idx);
        setStartDate(new Date(prefs.startDate));
        setEndDate(new Date(prefs.endDate));
      }
    };
    loadExisting();
  }, [route.params]);

  // 🔹 Submit preferences
    const submit = async () => {
  try {
    setLoading(true);

    const snap = await getDocs(
      query(collection(db, "destinations"), where("isArchived", "==", false))
    );
    const places = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

    const preferences = {
      startCity:
        useCurrentLocation && currentLocation
          ? currentLocation
          : START_CITIES[startCityIdx],
      startDate,
      endDate,
      maxBudget: Number(maxBudget) || 0,
      interests: Array.from(selectedInterests),
      priority,
    };

    const plan = buildItinerary(places, preferences);

    // ✅ carry old itinerary info when editing
    if (isEditing) {
      plan.itineraryId = route.params?.itineraryId;
      plan.savedItinerary = route.params?.savedItinerary;
    }

    navigation.navigate("ItineraryPreview", {
      plan,
      mode: isEditing ? "edit" : "create",
    });
  } catch (err) {
    console.error("Error building itinerary:", err);
    Alert.alert("Error", "Failed to generate itinerary.");
  } finally {
    setLoading(false);
  }
};


  // ---------- UI ----------
  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.title}>
            {isEditing ? "Edit Your Itinerary ✏️" : "Plan Your Adventure 🌴"}
          </Text>
          <Text style={styles.subtitle}>
            Customize your preferences for the best travel recommendations.
          </Text>

          {/* Location Picker */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons name="location-outline" size={20} color="#0f37f1" />
              <Text style={styles.cardTitle}>Starting Location</Text>
            </View>

            <View style={styles.pickerWrap}>
              <Picker selectedValue={startCityIdx} onValueChange={setStartCityIdx}>
                {START_CITIES.map((c, idx) => (
                  <Picker.Item key={c.label} label={c.label} value={idx} />
                ))}
              </Picker>
            </View>

            <TouchableOpacity
              style={[
                styles.toggleBtn,
                useCurrentLocation && { backgroundColor: "#dbeafe" },
              ]}
              onPress={async () => {
                if (useCurrentLocation) {
                  setUseCurrentLocation(false);
                  setCurrentLocation(null);
                  return;
                }

                const { status } = await Location.requestForegroundPermissionsAsync();
                if (status !== "granted") {
                  Alert.alert("Permission denied", "Location access required.");
                  return;
                }

                setLoading(true);
                try {
                  let pos = await Location.getLastKnownPositionAsync({});
                  if (!pos) {
                    pos = await Location.getCurrentPositionAsync({
                      accuracy: Location.Accuracy.Balanced,
                      maximumAge: 10000,
                      timeout: 5000,
                    });
                  }

                  if (pos) {
                    setCurrentLocation({
                      label: "Current Location",
                      lat: pos.coords.latitude,
                      lng: pos.coords.longitude,
                    });
                    setUseCurrentLocation(true);
                  } else {
                    Alert.alert("Location Error", "Unable to detect position.");
                  }
                } catch (err) {
                  Alert.alert("Error", "Please ensure GPS is enabled.");
                } finally {
                  setLoading(false);
                }
              }}
            >
              <Ionicons
                name={useCurrentLocation ? "navigate" : "navigate-outline"}
                size={16}
                color={useCurrentLocation ? "#0f37f1" : "#475569"}
                style={{ marginRight: 8 }}
              />
              <Text style={{ fontWeight: "600" }}>
                {useCurrentLocation ? "Using Current Location" : "Use My Location"}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Travel Dates */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons name="calendar-outline" size={20} color="#0f37f1" />
              <Text style={styles.cardTitle}>Travel Dates</Text>
            </View>
            <View style={styles.row}>
              <TouchableOpacity style={styles.dateBtn} onPress={() => setShowStart(true)}>
                <Text style={styles.dateText}>{formatDate(startDate)}</Text>
              </TouchableOpacity>
              <Text style={{ marginHorizontal: 8, color: "#64748b" }}>→</Text>
              <TouchableOpacity style={styles.dateBtn} onPress={() => setShowEnd(true)}>
                <Text style={styles.dateText}>{formatDate(endDate)}</Text>
              </TouchableOpacity>
            </View>
          </View>

          {showStart && (
            <DateTimePicker
              value={startDate}
              mode="date"
              onChange={(_, d) => {
                setShowStart(false);
                if (d) {
                  setStartDate(d);
                  if (d > endDate) setEndDate(new Date(d.getTime() + 86400000));
                }
              }}
            />
          )}
          {showEnd && (
            <DateTimePicker
              value={endDate}
              mode="date"
              onChange={(_, d) => {
                setShowEnd(false);
                if (d) setEndDate(d);
              }}
              minimumDate={startDate}
            />
          )}

          {/* Budget */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons name="cash-outline" size={20} color="#0f37f1" />
              <Text style={styles.cardTitle}>Budget</Text>
            </View>
            <TextInput
              style={styles.input}
              placeholder="Enter your max budget (₱)"
              keyboardType="number-pad"
              value={maxBudget}
              onChangeText={setMaxBudget}
            />
          </View>

          {/* Priority */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons name="options-outline" size={20} color="#0f37f1" />
              <Text style={styles.cardTitle}>Priority</Text>
            </View>
            <View style={styles.pickerWrap}>
              <Picker selectedValue={priority} onValueChange={setPriority}>
                <Picker.Item label="Balanced (Default)" value="balanced" />
                <Picker.Item label="Interest Focused" value="interest" />
                <Picker.Item label="Distance Focused" value="distance" />
                <Picker.Item label="Budget Focused" value="price" />
              </Picker>
            </View>
          </View>

          {/* Collapsible Interest Categories */}
          {Object.entries(INTEREST_CATEGORIES).map(([key, cat]) => {
            const expanded = expandedSections[key];
            return (
              <View key={key} style={styles.card}>
                <TouchableOpacity
                  style={styles.collapseHeader}
                  onPress={() => toggleSection(key)}
                  activeOpacity={0.8}
                >
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Ionicons
                      name={cat.icon}
                      size={18}
                      color="#0f37f1"
                      style={{ marginRight: 8 }}
                    />
                    <Text style={styles.sectionTitle}>{cat.label}</Text>
                  </View>
                  <Ionicons
                    name={expanded ? "chevron-up" : "chevron-down"}
                    size={18}
                    color="#64748b"
                  />
                </TouchableOpacity>

                {expanded && (
                  <>
                    <Text style={styles.categorySubtitle}>
                      Select interests related to {cat.label.toLowerCase()}
                    </Text>
                    <View style={styles.tagsGrid}>
                      {cat.items.map((item) => {
                        const active = selectedInterests.has(item.key);
                        return (
                          <TouchableOpacity
                            key={item.key}
                            onPress={() => toggleInterest(item.key)}
                            style={[
                              styles.tagBox,
                              active && { backgroundColor: "#e0f2fe", borderColor: "#0ea5e9" },
                            ]}
                          >
                            <Ionicons
                              name={active ? "checkmark-circle" : "ellipse-outline"}
                              size={14}
                              color={active ? "#0284c7" : "#94a3b8"}
                              style={{ marginRight: 6 }}
                            />
                            <Text
                              numberOfLines={1}
                              style={{
                                color: active ? "#0369a1" : "#1e293b",
                                fontSize: 13,
                                flexShrink: 1,
                              }}
                            >
                              {item.label}
                            </Text>
                          </TouchableOpacity>
                        );
                      })}
                    </View>
                  </>
                )}
              </View>
            );
          })}

          <View style={styles.footerSpacer} />
        </ScrollView>

        {/* Sticky Footer */}
        <View style={styles.footerContainer}>
          <TouchableOpacity
            style={[styles.btn, styles.btnGhost, { flex: 0.6 }]}
            onPress={() => navigation.goBack()}
          >
            <Text style={[styles.btnText, { color: "#0f172a" }]}>Cancel</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.btn, styles.btnPrimary, { flex: 1.4 }]}
            onPress={submit}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="sparkles-outline" size={18} color="#fff" />
                <Text style={styles.btnText}>
                  {isEditing ? "Update Plan" : "Discover Destinations"}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ---------- Styles ----------
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f8fafc" },
  container: { padding: 16, paddingBottom: 100 },
  title: { fontSize: 22, fontWeight: "800", color: "#0f172a", marginBottom: 4 },
  subtitle: { color: "#475569", marginBottom: 14 },
  card: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  cardHeader: { flexDirection: "row", alignItems: "center", marginBottom: 8 },
  cardTitle: { fontSize: 16, fontWeight: "700", marginLeft: 8, color: "#0f172a" },
  pickerWrap: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    overflow: "hidden",
  },
  toggleBtn: {
    marginTop: 8,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    padding: 10,
  },
  row: { flexDirection: "row", alignItems: "center" },
  dateBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "#f8fafc",
  },
  dateText: { fontWeight: "600", color: "#0f172a" },
  input: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#f8fafc",
    color: "#0f172a",
  },
  sectionTitle: { fontWeight: "700", fontSize: 15, color: "#0f172a" },
  categorySubtitle: { fontSize: 12, color: "#64748b", marginBottom: 8 },
  tagsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 8,
  },
  tagBox: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
    width: "48%",
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    backgroundColor: "#fff",
    marginBottom: 8,
  },
  footerContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#fff",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderColor: "#e2e8f0",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 5,
  },
  footerSpacer: { height: 100 },
  btn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  btnGhost: { backgroundColor: "#f1f5f9" },
  btnPrimary: { backgroundColor: "#0f37f1" },
  btnText: { color: "#fff", fontWeight: "800" },
  collapseHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 4,
  },
});
