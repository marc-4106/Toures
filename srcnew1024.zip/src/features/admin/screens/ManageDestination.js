import React, { useEffect, useState } from "react";
import { View, FlatList, TextInput, Pressable, Text, StyleSheet } from "react-native";
import { getAuth } from "firebase/auth";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import { logActivity } from "../../../services/firestoreReportsAndLogs";
import {
    fetchDestinations,
    addDestination,
    updateDestination,
    archiveDestination,
    unarchiveDestination,
} from "../../../services/firestoreDestinations";
// Assuming DestinationItem and DestinationModal are correctly imported
import DestinationItem from "../../../components/common/DestinationItem"; 
import DestinationModal from "../../../components/common/DestinationModal"; 
// Assuming ContactUtils contains isEmail and toE164PH (though not used here)
import { isEmail, toE164PH } from "../../recommender/ContactUtils"; 

// ✅ Limit kind to the set you requested (saved as lowercase in the modal)
const KIND_OPTIONS = ["Hotel", "Restaurant", "Resort", "Mall", "Heritage"];

const guessKind = (data) => {
    const raw = data || {};
    const cats = (raw.tags || raw.categories || [])
        .map(String)
        .map((s) => s.toLowerCase());
    if (cats.includes("restaurant")) return "restaurant";
    if (cats.includes("hotel")) return "hotel";
    if (cats.includes("resort")) return "resort";
    if (cats.includes("mall")) return "mall";
    if (cats.includes("heritage") || cats.includes("culture")) return "heritage";
    return raw.kind || "activity";
};

const sanitizeTags = (arr = []) =>
    Array.from(new Set(arr.map((t) => String(t).toLowerCase().trim()).filter(Boolean)));

// Add this helper near the top of the file
const toNumOrZero = (v) => {
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : 0;
};


const INITIAL_FORM_STATE = {
    name: "",
    description: "",
    imageUrl: "",
    cityOrMunicipality: "", // ✨ Added this new field
    kind: "",                 // "hotel", "restaurant", etc. (lowercase)
    tags: [],                 // multi-select chips
    isFeatured: false,
    Coordinates: {
        latitude: "",
        longitude: "",
    },
    contact: {
        email: "",
        phoneRaw: "",
    },
    pricing: {
        lodging: { base: "" }, // string in form; parse on save
        mealPlan: {
            breakfastIncluded: false,
            lunchIncluded: false,
            dinnerIncluded: false,
            aLaCarteDefault: "300",
        },
        dayUse: { dayPassPrice: "" },
    },
};

const ManageDestination = () => {
    const [destinations, setDestinations] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [form, setForm] = useState(INITIAL_FORM_STATE);
    const [editId, setEditId] = useState(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [showArchived, setShowArchived] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [saveError, setSaveError] = useState(null);

    const getAdminUserNameFromFirestore = async () => {
        const auth = getAuth();
        const user = auth.currentUser;
        if (!user) return "Guest/Unauthenticated";
        try {
            const db = getFirestore(auth.app);
            const userDocRef = doc(db, "users", user.uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) return userDoc.data().name || user.email || user.uid;
            return user.email || user.uid;
        } catch (error) {
            console.error("Failed to fetch user name from Firestore:", error);
            return "Admin User Error";
        }
    };

    const loadData = async () => {
        const data = await fetchDestinations();
        setDestinations(data);
    };

    useEffect(() => { loadData(); }, []);

    // ------------------------------------------------------------------
    // Save Handler (Removed idealCost and Added cityOrMunicipality)
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
// Save Handler (now includes activities[])
// ------------------------------------------------------------------
const handleSave = async () => {
  setSaveError(null);
  setIsLoading(true);

  // 1) Who is saving (for logs)
  const ACTOR_NAME = await getAdminUserNameFromFirestore();

  // 2) Basic validation
  const destinationName = (form.name || "").trim();
  if (!destinationName) {
    setSaveError("Destination name cannot be empty.");
    setIsLoading(false);
    return;
  }

  // 3) Normalize & parse BEFORE writing
  const payload = {
    // pass-through strings/arrays/booleans
    name: destinationName,
    description: form.description?.trim() || "",
    imageUrl: form.imageUrl?.trim() || "",
    cityOrMunicipality: form.cityOrMunicipality?.trim() || "",
    kind: (form.kind || "").toLowerCase(),
    tags: Array.isArray(form.tags) ? form.tags.map(String) : [],
    isFeatured: !!form.isFeatured,

    // ✅ include activities (clean and trimmed)
    activities: Array.isArray(form.activities)
      ? form.activities.filter((a) => a && a.trim() !== "").map((a) => a.trim())
      : [],

    // coordinates -> numbers
    Coordinates: {
      latitude: toNumOrZero(form?.Coordinates?.latitude),
      longitude: toNumOrZero(form?.Coordinates?.longitude),
    },

    // contact
    contact: {
      email: (form?.contact?.email || "").trim(),
      phoneRaw: (form?.contact?.phoneRaw || "").trim(),
    },

    // pricing (parsed carefully; keep structure even if 0)
    pricing: {
      lodging: {
        base: toNumOrZero(form?.pricing?.lodging?.base),
      },
      mealPlan: {
        breakfastIncluded: !!form?.pricing?.mealPlan?.breakfastIncluded,
        lunchIncluded: !!form?.pricing?.mealPlan?.lunchIncluded,
        dinnerIncluded: !!form?.pricing?.mealPlan?.dinnerIncluded,
        aLaCarteDefault: toNumOrZero(form?.pricing?.mealPlan?.aLaCarteDefault ?? 300),
      },
      dayUse: {
        dayPassPrice: toNumOrZero(form?.pricing?.dayUse?.dayPassPrice),
      },
    },
  };

  try {
    if (editId) {
      await updateDestination(editId, payload);

      logActivity({
        actorName: ACTOR_NAME,
        actionType: "UPDATE",
        targetEntity: "Destination",
        targetId: editId,
        details: `Updated destination: ${destinationName}`,
      });
    } else {
      const newDoc = await addDestination({ ...payload, isArchived: false });

      logActivity({
        actorName: ACTOR_NAME,
        actionType: "CREATE",
        targetEntity: "Destination",
        targetId: newDoc.id,
        details: `Created destination: ${destinationName}`,
      });
    }

    setModalVisible(false);
    setForm(INITIAL_FORM_STATE);
    setEditId(null);
    loadData();
  } catch (error) {
    console.error("Firestore Save Error:", error);
    setSaveError("An error occurred while saving. Please check your data and network.");
  } finally {
    setIsLoading(false);
  }
};

// ------------------------------------------------------------------
// Edit Handler (includes activities field)
// ------------------------------------------------------------------
const handleEdit = (item) => {
  setForm({
    // straight copy for simple fields
    name: item.name || "",
    description: item.description || "",
    imageUrl: item.imageUrl || item.imageURL || "",
    cityOrMunicipality: item.cityOrMunicipality || "",
    kind: (item.kind || "").toLowerCase(),
    tags: Array.isArray(item.tags) ? item.tags : (item.categories || []),
    isFeatured: item.isFeatured === true,

    // ✅ include activities
    activities: Array.isArray(item.activities) ? item.activities : [],

    // Coordinates
    Coordinates: {
      latitude:
        item?.Coordinates?.latitude != null
          ? String(item.Coordinates.latitude)
          : item?.coordinates?.latitude != null
          ? String(item.coordinates.latitude)
          : "",
      longitude:
        item?.Coordinates?.longitude != null
          ? String(item.Coordinates.longitude)
          : item?.coordinates?.longitude != null
          ? String(item.coordinates.longitude)
          : "",
    },

    // Contact
    contact: {
      email: item?.contact?.email || "",
      phoneRaw: item?.contact?.phoneRaw || "",
    },

    // Pricing
    pricing: {
      lodging: {
        base:
          item?.pricing?.lodging?.base != null
            ? String(item.pricing.lodging.base)
            : "",
      },
      mealPlan: {
        breakfastIncluded: !!item?.pricing?.mealPlan?.breakfastIncluded,
        lunchIncluded: !!item?.pricing?.mealPlan?.lunchIncluded,
        dinnerIncluded: !!item?.pricing?.mealPlan?.dinnerIncluded,
        aLaCarteDefault:
          item?.pricing?.mealPlan?.aLaCarteDefault != null
            ? String(item.pricing.mealPlan.aLaCarteDefault)
            : "300",
      },
      dayUse: {
        dayPassPrice:
          item?.pricing?.dayUse?.dayPassPrice != null
            ? String(item.pricing.dayUse.dayPassPrice)
            : "",
      },
    },
  });

  setEditId(item.id);
  setModalVisible(true);
};



    const handleArchive = async (id, name) => {
        const ACTOR_NAME = await getAdminUserNameFromFirestore();
        await archiveDestination(id);
        loadData();
        logActivity({ actorName: ACTOR_NAME, actionType: "ARCHIVE", targetEntity: "Destination", targetId: id, details: `Archived destination: ${name}` });
    };

    const handleUnarchive = async (id, name) => {
        const ACTOR_NAME = await getAdminUserNameFromFirestore();
        await unarchiveDestination(id);
        loadData();
        logActivity({ actorName: ACTOR_NAME, actionType: "UNARCHIVE", targetEntity: "Destination", targetId: id, details: `Unarchived destination: ${name}` });
    };

    const handleToggleFeatured = async (id, name, value) => {
        const ACTOR_NAME = await getAdminUserNameFromFirestore();
        await updateDestination(id, { isFeatured: value });
        loadData();
        logActivity({ actorName: ACTOR_NAME, actionType: "TOGGLE_FEATURED", targetEntity: "Destination", targetId: id, details: `Set featured status to ${value} for destination: ${name}` });
    };

    const handleItemAction = (actionFunction, item) => actionFunction(item.id, item.name);

    const visibleDestinations = destinations
        .filter((d) => (showArchived ? d.isArchived : !d.isArchived))
        .filter((d) => {
            const q = (searchQuery || "").toLowerCase();
            const name = (d.name || "").toLowerCase();
            const tgs = ((d.tags || []).join(", ") || "").toLowerCase();
            const city = (d.cityOrMunicipality || "").toLowerCase(); // Check city/municipality
            return name.includes(q) || tgs.includes(q) || city.includes(q);
        });

    const renderItem = ({ item }) => (
        <DestinationItem
            item={item}
            onEdit={handleEdit}
            onArchive={() => handleItemAction(handleArchive, item)}
            onUnarchive={() => handleItemAction(handleUnarchive, item)}
            onToggleFeatured={(value) => handleToggleFeatured(item.id, item.name, value)}
            isArchivedView={showArchived}
        />
    );

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.searchInput}
                placeholder={showArchived ? "Search archived..." : "Search destinations..."}
                placeholderTextColor="#999"
                value={searchQuery}
                onChangeText={setSearchQuery}
            />

            <Pressable
                style={[styles.toggleButton, showArchived ? styles.toggleActive : null]}
                onPress={() => setShowArchived(!showArchived)}
            >
                <Text style={[styles.toggleButtonText, showArchived ? styles.toggleActiveText : null]}>
                    {showArchived ? "← Back to Active" : "📂 Show Archived"}
                </Text>
            </Pressable>

            {!showArchived && (
                <Pressable
                    style={styles.addButton}
                    onPress={() => {
                        setForm(INITIAL_FORM_STATE);
                        setEditId(null);
                        setSaveError(null);
                        setModalVisible(true);
                    }}
                >
                    <Text style={styles.addButtonText}>+ Add Destination</Text>
                </Pressable>
            )}

            <FlatList data={visibleDestinations} keyExtractor={(item) => item.id} renderItem={renderItem} />

            <DestinationModal
                visible={modalVisible}
                onClose={() => {
                    setModalVisible(false);
                    setForm(INITIAL_FORM_STATE);
                    setEditId(null);
                    setSaveError(null);
                }}
                onSave={handleSave}
                form={form}
                setForm={setForm}
                editId={editId}
                isLoading={isLoading}
                error={saveError}
                kindOptions={KIND_OPTIONS}
            />
        </View>
    );
};

export default ManageDestination;

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: "#f8f9fa", padding: 20 },
    searchInput: { borderWidth: 1, borderColor: "#ddd", borderRadius: 8, padding: 10, marginBottom: 10, fontSize: 16, color: "#333" },
    addButton: { backgroundColor: "#0f37f1", paddingVertical: 10, paddingHorizontal: 24, borderRadius: 25, alignSelf: "flex-start", marginBottom: 10, elevation: 3 },
    addButtonText: { color: "#fff", fontSize: 15, fontWeight: "600" },
    toggleButton: { backgroundColor: "#ddd", paddingVertical: 8, paddingHorizontal: 18, borderRadius: 25, alignSelf: "flex-start", marginBottom: 10, elevation: 2 },
    toggleButtonText: { fontWeight: "600", color: "#333", fontSize: 14 },
    toggleActiveText: { color: "#fff" },
    toggleActive: { backgroundColor: "#0f37f1" },
});