// src/features/user/components/ItineraryPreview.js
import React, { useMemo, useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Switch } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { activityCost } from "../logic/fuzzy/cost";

import { haversineKm } from "../../recommender/distance";

import DestinationPreviewModal from "./DestinationPreviewModal";
import { fuzzyScore } from "../logic/fuzzy/score";


// ------------------------------------------------------------------
//  SCORE LABEL HELPER
// ------------------------------------------------------------------
function scoreLabel(score) {
  const pct = Math.round(score * 100);
  if (pct >= 85) return { text: `Excellent (${pct}%)`, color: "#16a34a" }; // green
  if (pct >= 65) return { text: `Good (${pct}%)`, color: "#ccab28ff" };      // yellow
  if (pct >= 45) return { text: `Fair (${pct}%)`, color: "#f97316" };      // orange
  return { text: `Low (${pct}%)`, color: "#dc2626" };                      // red
}




function kmText(km) {
  if (!Number.isFinite(km)) return "—";
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(1)} km`;
}

function Peso({ value }) {
  const v = Number(value || 0);
  return <Text style={styles.peso}>₱{v.toLocaleString()}</Text>;
}

function SmallButton({ title, onPress, disabled }) {
  return (
    <TouchableOpacity onPress={onPress} disabled={disabled} style={[styles.sbtn, disabled && { opacity: 0.4 }]}>
      <Text style={styles.sbtnText}>{title}</Text>
    </TouchableOpacity>
  );
}

function TabBar({ tabs, current, onChange }) {
  return (
    <View style={styles.tabBar}>
      {tabs.map((t, idx) => {
        const active = current === idx;
        return (
          <TouchableOpacity key={t.key} onPress={() => onChange(idx)} style={[styles.tab, active && styles.tabActive]}>
            <Text style={[styles.tabText, active && styles.tabTextActive]}>{t.label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function DayTabs({ daysCount, day, setDay }) {
  if (!Number.isFinite(daysCount) || daysCount <= 1) return null;
  const days = Array.from({ length: daysCount }, (_, i) => i + 1);
  return (
    <View style={styles.dayTabs}>
      {days.map((d) => {
        const active = d === day;
        return (
          <TouchableOpacity key={d} onPress={() => setDay(d)} style={[styles.dayTab, active && styles.dayTabActive]}>
            <Text style={[styles.dayTabText, active && styles.dayTabTextActive]}>Day {d}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export default function ItineraryPreview({ plan, onSave }) {
  const [tab, setTab] = useState(0);
  const [mealTab, setMealTab] = useState(0); // 0: Breakfast, 1: Lunch, 2: Dinner

  // Nights from plan.meta.nights; days = nights + 1 (inclusive range)
  const nights = Number(plan?.meta?.nights || 0);
  const daysCount = Math.max(1, nights + 1);

  // --- Selection state ---
  const [primaryHotel, setPrimaryHotel] = useState(null);
  const [allowSplitStay, setAllowSplitStay] = useState(nights > 2);
  const [secondaryHotel, setSecondaryHotel] = useState(null);

  const [dayIdx, setDayIdx] = useState(1);
  const blankDay = { breakfast: null, lunch: null, dinner: null, activities: [] };
  const [selectedDays, setSelectedDays] = useState(
    Array.from({ length: daysCount }, () => ({ ...blankDay }))
  );



  const [previewModalVisible, setPreviewModalVisible] = useState(false);
  const [previewDestination, setPreviewDestination] = useState(null);



 const handleOpenPreview = (p) => {
  setPreviewDestination(p);
  setPreviewModalVisible(true);
};


  // ⭐ MODIFIED TIERLIST COMPONENT (ADDED renderLeftContent PROP)
  function TierList({ title, items, renderRight, renderLeftContent }) {
    if (!Array.isArray(items) || items.length === 0) return null;

    return (
      <View style={styles.tier}>
        <Text style={styles.tierTitle}>{title}</Text>

        {items.map((p) => {
          // ✅ Step 2 — compute distance from the plan’s start city
          const start = plan?.meta?.startCity;
          let kmFromStart = null;

          if (
            start &&
            Number.isFinite(start.lat) &&
            Number.isFinite(start.lng) &&
            p?.Coordinates?.latitude &&
            p?.Coordinates?.longitude
          ) {
            kmFromStart = haversineKm(
              start.lat,
              start.lng,
              p.Coordinates.latitude,
              p.Coordinates.longitude
            );
          }
            // ⭐ Compute fuzzy score
        const score = fuzzyScore(p, plan?.meta, [p.kind || ""]);

          return (
            <TouchableOpacity
              key={p.id}
              style={styles.card}
              onPress={() => handleOpenPreview(p)}
              activeOpacity={0.85}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.placeName}>{p.name || p.title}</Text>
                <Text style={styles.placeMeta}>
                  {(p.kind || "").toUpperCase()} • {p.cityOrMunicipality || "—"} •{" "}
                  {kmFromStart ? kmText(kmFromStart) : "—"}
                </Text>
               {typeof score === "number" && (
  <Text
    style={{
      alignSelf: "flex-start",
      backgroundColor: scoreLabel(score).color + "20",
      color: scoreLabel(score).color,
      fontSize: 12,
      fontWeight: "700",
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      marginTop: 3,
    }}
  >
    {scoreLabel(score).text}
  </Text>
)}

                
                {/* ⭐ RENDER CUSTOM LEFT CONTENT HERE (Activity Bullets) */}
                {renderLeftContent?.(p)} 

              </View>

              <View style={{ alignItems: "flex-end" }}>{renderRight?.(p)}</View>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  }
  // ------------------------------------------------------------------
 


  // --- Recommendations (preserved) ---
  const hotelReco = useMemo(() => {
    const alts = plan?.accommodation?.alternatives || { highly: [], considerable: [] };
    const filter = (p) =>
      ["hotel", "resort"].includes((p.kind || "").toLowerCase()) ||
      (Array.isArray(p.tags) && p.tags.map((t) => String(t).toLowerCase()).includes("lodging"));
    return {
      highly: (alts.highly || []).filter(filter),
      considerable: (alts.considerable || []).filter(filter),
      nights: nights,
    };
  }, [plan, nights]);

  const mealReco = useMemo(() => {
    const day = (plan?.days || [])[1] || plan?.days?.[0] || null;
    const pick = (slot) => {
      const alt = day?.[slot]?.alternatives || { highly: [], considerable: [] };
      const filter = (p) =>
        (p.kind || "").toLowerCase() === "restaurant" ||
        (Array.isArray(p.tags) && p.tags.map((t) => String(t).toLowerCase()).includes("foodie"));
      return {
        highly: (alt.highly || []).filter(filter),
        considerable: (alt.considerable || []).filter(filter),
      };
    };
    return ["breakfast", "lunch", "dinner"].map(pick);
  }, [plan]);

  const activityReco = useMemo(() => {
    const alts = plan?.alternatives?.activity || { highly: [], considerable: [] };
    const filt = (p) => !["hotel", "restaurant"].includes(String(p.kind || "").toLowerCase());
    const decorate = (arr) =>
      (arr || []).filter(filt).map((p) => ({
        ...p,
        // Mocking activities for demonstration based on your request, 
        // as the actual data structure from the 'plan' is unknown
        activities: p.activities || (p.name === 'The Ruins' ? ["Guided Tour", "Photography Spot", "Souvenir Shop"] : []),
        computedCost: Number(activityCost(p)) || 0,
      }));
    return {
      highly: decorate(alts.highly),
      considerable: decorate(alts.considerable),
    };
  }, [plan]);

  const tabs = [
    { key: "lodging", label: "Lodging" },
    { key: "meals", label: "Meals" },
    { key: "activities", label: "Activities" },
    { key: "build", label: "Build Plan" },
  ];

  const mealTabs = [
    { key: "breakfast", label: "Breakfast" },
    { key: "lunch", label: "Lunch" },
    { key: "dinner", label: "Dinner" },
  ];

  // --- Select handlers ---
  // Hotel selectable at 2 days / 1 night and beyond (nights >= 1)
  const canPickHotel = nights >= 1;

  const pickHotel = (p) => {
    // ✅ Deselect if tapped again
    if (primaryHotel?.id === p.id) {
      setPrimaryHotel(null);
      setSecondaryHotel(null);
      return;
    }

    if (allowSplitStay && nights > 2) {
      if (!primaryHotel) {
        setPrimaryHotel(p);
      } else if (!secondaryHotel && p?.id !== primaryHotel?.id) {
        setSecondaryHotel(p);
      } else if (secondaryHotel?.id === p.id) {
        setSecondaryHotel(null);
      } else {
        setPrimaryHotel(p);
      }
    } else {
      setPrimaryHotel(p);
      setSecondaryHotel(null);
    }
  };

  const setMealForDay = (slot, p) => {
    setSelectedDays((prev) => {
      const next = [...prev];
      const idx = Math.max(1, Math.min(daysCount, dayIdx)) - 1;
      next[idx] = { ...next[idx], [slot]: p };
      return next;
    });
  };

  const toggleActivityForDay = (p) => {
    setSelectedDays((prev) => {
      const next = [...prev];
      const idx = Math.max(1, Math.min(daysCount, dayIdx)) - 1;
      const arr = Array.isArray(next[idx]?.activities) ? [...next[idx].activities] : [];
      const i = arr.findIndex((x) => x.id === p.id);
      if (i >= 0) arr.splice(i, 1);
      else arr.push(p);
      next[idx] = { ...next[idx], activities: arr };
      return next;
    });
  };

  // --- Totals ---
  const totalHotelCost = useMemo(() => {
    const nightsCount = nights;
    if (!primaryHotel) return 0;
    const nightP = Number(primaryHotel.nightlyPrice || 0);
    const primaryCost = nightP * nightsCount;
    let secondaryCost = 0;
    if (allowSplitStay && secondaryHotel && nightsCount > 2) {
      const half = Math.floor(nightsCount / 2);
      secondaryCost = Number(secondaryHotel.nightlyPrice || 0) * (nightsCount - half);
      return Number(secondaryCost + nightP * half);
    }
    return Number(primaryCost);
  }, [primaryHotel, secondaryHotel, allowSplitStay, nights]);

  const totalMealsCost = useMemo(() => {
    return selectedDays.reduce((sum, d) => {
      const b = Number(d?.breakfast?.computedCost || 0);
      const l = Number(d?.lunch?.computedCost || 0);
      const di = Number(d?.dinner?.computedCost || 0);
      return sum + b + l + di;
    }, 0);
  }, [selectedDays]);

  const totalActivitiesCost = useMemo(() => {
    return selectedDays.reduce((sum, d) => {
      const arr = Array.isArray(d?.activities) ? d.activities : [];
      const s = arr.reduce((acc, a) => acc + Number(a?.computedCost || 0), 0);
      return sum + s;
    }, 0);
  }, [selectedDays]);

  // Budget/exceed flag
  const grandTotal = useMemo(
    () => Number(totalHotelCost + totalMealsCost + totalActivitiesCost),
    [totalHotelCost, totalMealsCost, totalActivitiesCost]
  );
  const maxBudget = Number(plan?.meta?.maxBudget || 0);
  const budgetExceeded = maxBudget > 0 && grandTotal > maxBudget;

  // --- Save helpers ---
  const finalizeSave = () => {
    const out = {
      meta: plan?.meta,
      hotels: {
        primary: primaryHotel || null,
        secondary: allowSplitStay && nights > 2 ? secondaryHotel || null : null,
        allowSplitStay: !!allowSplitStay,
      },
      days: selectedDays.map((d, idx) => ({
        day: idx + 1,
        breakfast: d.breakfast,
        lunch: d.lunch,
        dinner: d.dinner,
        activities: Array.isArray(d.activities) ? d.activities : [],
      })),
      totals: {
        hotel: Number(totalHotelCost || 0),
        meals: Number(totalMealsCost || 0),
        activities: Number(totalActivitiesCost || 0),
        grandTotal: Number(grandTotal || 0),
      },
      source: { type: "recommendations" },
      createdAt: new Date().toISOString(),
    };
    if (typeof onSave === "function") onSave(out);
    else Alert.alert("Save", "Connect `onSave` to persist this itinerary.", [{ text: "OK" }]);
  };

  const handleSave = () => {
    // If nights >= 2 (2+ nights), require at least one hotel
    if (nights >= 2 && !primaryHotel) {
      Alert.alert("Choose a hotel", "Please select at least one hotel for your stay.");
      return;
    }
    // Meals validation
    for (let i = 0; i < selectedDays.length; i++) {
      const d = selectedDays[i] || {};
      if (!d.breakfast || !d.lunch || !d.dinner) {
        Alert.alert("Complete meals", "Please choose breakfast, lunch, and dinner for Day " + (i + 1) + ".");
        return;
      }
    }
    // Budget guard
    if (budgetExceeded) {
      Alert.alert(
        "Over budget",
        "Your grand total (₱" + grandTotal.toLocaleString() + ") exceeds your max budget (₱" + maxBudget.toLocaleString() + ").",
        [
          { text: "Adjust", style: "cancel" },
          { text: "Save anyway", style: "destructive", onPress: () => finalizeSave() },
        ]
      );
      return;
    }
    finalizeSave();
  };
  
  // ------------------------------------------------------------------
  // ⭐ ActivityBullets Definition (Moved outside conditional rendering)
  // ------------------------------------------------------------------
  const renderActivityBullets = (p) => {
      const listedActs = Array.isArray(p.activities) ? p.activities : [];
      if (listedActs.length === 0) {
        return (
          <Text style={{ fontSize: 11, color: "#9ca3af", marginTop: 4 }}>
            No listed activities
          </Text>
        );
      }
      return (
        <View style={{ marginTop: 6, alignItems: "flex-start" }}>
          {listedActs.map((act, idx) => (
            <Text
              key={idx}
              style={{ fontSize: 11, color: "#475569", marginBottom: 1 }}
            >
              • {act}
            </Text>
          ))}
        </View>
      );
  };
  // ------------------------------------------------------------------


  return (
    <View style={{ flex: 1, backgroundColor: "#f9fafb" }}>
      <View style={styles.header}>
        <Text style={styles.screenTitle}>Recommendations</Text>
      </View>

      <TabBar tabs={tabs} current={tab} onChange={setTab} />

      <ScrollView contentContainerStyle={styles.container}>
        {tab === 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="bed-outline" size={18} color="#1f2937" />
              <Text style={styles.sectionTitle}>Hotels & Accommodation</Text>
            </View>

            {nights < 2 && (
              <Text style={styles.note}>
                Hotel selection is available for trips of{" "}
                <Text style={{ fontWeight: "700" }}>2 days / 1 night and beyond</Text>.
              </Text>
            )}

            {nights > 2 && (
              <View style={styles.rowBetween}>
                <Text style={styles.smallLabel}>Allow split-stay (optional)</Text>
                <Switch value={allowSplitStay} onValueChange={setAllowSplitStay} />
              </View>
            )}

            <TierList
              title="Highly Recommended"
              items={hotelReco.highly}
              renderRight={(p) => (
                <View style={{ alignItems: "flex-end" }}>
                  <Peso value={p.totalCost ?? hotelReco.nights * (p.nightlyPrice || 0)} />
                  <Text style={styles.subNote}>for {hotelReco.nights} night(s)</Text>
                  <SmallButton
                    title={
                      (primaryHotel?.id === p.id && "Primary ✓") ||
                      (secondaryHotel?.id === p.id && "Secondary ✓") ||
                      "Select"
                    }
                    onPress={() => pickHotel(p)}
                    disabled={!canPickHotel}
                  />
                </View>
              )}
            />
            <TierList
              title="Considerate"
              items={hotelReco.considerable}
              renderRight={(p) => (
                <View style={{ alignItems: "flex-end" }}>
                  <Peso value={p.totalCost ?? hotelReco.nights * (p.nightlyPrice || 0)} />
                  <Text style={styles.subNote}>for {hotelReco.nights} night(s)</Text>
                  <SmallButton
                    title={
                      (primaryHotel?.id === p.id && "Primary ✓") ||
                      (secondaryHotel?.id === p.id && "Secondary ✓") ||
                      "Select"
                    }
                    onPress={() => pickHotel(p)}
                    disabled={!canPickHotel}
                  />
                </View>
              )}
            />
          </View>
        )}

        {tab === 1 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="restaurant-outline" size={18} color="#1f2937" />
              <Text style={styles.sectionTitle}>Meal Plan</Text>
            </View>

            <DayTabs daysCount={daysCount} day={dayIdx} setDay={setDayIdx} />
            <TabBar tabs={mealTabs} current={mealTab} onChange={setMealTab} />

            {/* Breakfast / Lunch / Dinner sub-tab */}
            <TierList
              title="Highly Recommended"
              items={mealReco[mealTab]?.highly}
              renderRight={(p) => {
                const slot = mealTabs[mealTab].key;
                const current = selectedDays?.[dayIdx - 1]?.[slot]?.id || null;
                const isSel = current === p.id;
                return (
                  <SmallButton
                    title={isSel ? "Selected ✓" : "Select"}
                    onPress={() => setMealForDay(slot, p)}
                    disabled={isSel}
                  />
                );
              }}
            />
            <TierList
              title="Considerate"
              items={mealReco[mealTab]?.considerable}
              renderRight={(p) => {
                const slot = mealTabs[mealTab].key;
                const current = selectedDays?.[dayIdx - 1]?.[slot]?.id || null;
                const isSel = current === p.id;
                return (
                  <SmallButton
                    title={isSel ? "Selected ✓" : "Select"}
                    onPress={() => setMealForDay(slot, p)}
                    disabled={isSel}
                  />
                );
              }}
            />

            {/* Current selection preview for the day */}
            <View style={[styles.section, { marginTop: 6 }]}>
              <Text style={styles.tierTitle}>Day {dayIdx} — Chosen Meals</Text>
              <Text style={styles.selLine}>Breakfast: {selectedDays[dayIdx - 1]?.breakfast?.name || "—"}</Text>
              <Text style={styles.selLine}>Lunch: {selectedDays[dayIdx - 1]?.lunch?.name || "—"}</Text>
              <Text style={styles.selLine}>Dinner: {selectedDays[dayIdx - 1]?.dinner?.name || "—"}</Text>
            </View>
          </View>
        )}

        {/* ------------------------------------------------------------------ */}
        {/* ⭐ CORRECTED TAB === 2 SECTION (Uses renderActivityBullets) */}
        {/* ------------------------------------------------------------------ */}
        {tab === 2 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="bicycle-outline" size={18} color="#1f2937" />
              <Text style={styles.sectionTitle}>Activities</Text>
            </View>

            <DayTabs daysCount={daysCount} day={dayIdx} setDay={setDayIdx} />
            
            <TierList
              title="Highly Recommended"
              items={activityReco.highly}
              renderLeftContent={renderActivityBullets} // ⭐ Passed as a function reference
              renderRight={(p) => {
                const selected =
                  (selectedDays[dayIdx - 1]?.activities || []).some((x) => x.id === p.id);
                return (
                  <SmallButton
                    title={selected ? "Remove" : "Add"}
                    onPress={() => toggleActivityForDay(p)}
                  />
                );
              }}
            />

            <TierList
              title="Considerate"
              items={activityReco.considerable}
              renderLeftContent={renderActivityBullets} // ⭐ Passed as a function reference
              renderRight={(p) => {
                const selected =
                  (selectedDays[dayIdx - 1]?.activities || []).some((x) => x.id === p.id);
                return (
                  <SmallButton
                    title={selected ? "Remove" : "Add"}
                    onPress={() => toggleActivityForDay(p)}
                  />
                );
              }}
            />

            {/* Current selection preview for the day */}
            <View style={[styles.section, { marginTop: 6 }]}>
              <Text style={styles.tierTitle}>Day {dayIdx} — Activities</Text>
              <Text style={styles.selLine}>
                {(selectedDays[dayIdx - 1]?.activities || [])
                  .map((a) => a.name || a.title)
                  .join(", ") || "—"}
              </Text>
            </View>
          </View>
        )}
        {/* ------------------------------------------------------------------ */}


        {tab === 3 && (
          <View style={styles.section}>
            {/* Budget banner */}
            {budgetExceeded && (
              <View
                style={{
                  backgroundColor: "#FEF2F2",
                  borderColor: "#FCA5A5",
                  borderWidth: 1,
                  borderRadius: 8,
                  padding: 10,
                  marginBottom: 8,
                }}
              >
                <Text style={{ color: "#991B1B", fontWeight: "800" }}>Over budget</Text>
                <Text style={{ color: "#7F1D1D" }}>
                  Max budget: ₱{maxBudget.toLocaleString()} • Current total: ₱{grandTotal.toLocaleString()}
                </Text>
              </View>
            )}

            <Text style={styles.sectionTitle}>Build Plan — Summary</Text>
            <Text style={styles.selLine}>
              Hotel: {primaryHotel?.name || "—"}
              {allowSplitStay && secondaryHotel ? ` + ${secondaryHotel.name}` : ""}
            </Text>
            <Text style={styles.selLine}>Hotel Cost: <Peso value={totalHotelCost} /></Text>
            <View style={{ height: 8 }} />
            {selectedDays.map((d, idx) => (
              <View key={idx} style={{ marginBottom: 8 }}>
                <Text style={styles.tierTitle}>Day {idx + 1}</Text>
                <Text style={styles.selLine}>Breakfast: {d.breakfast?.name || "—"}</Text>
                <Text style={styles.selLine}>Lunch: {d.lunch?.name || "—"}</Text>
                <Text style={styles.selLine}>Dinner: {d.dinner?.name || "—"}</Text>
                <Text style={styles.selLine}>
                  Activities: {(d.activities || []).map((a) => a.name || a.title).join(", ") || "—"}
                </Text>
              </View>
            ))}
            <View style={{ height: 8 }} />
            <Text style={styles.selLine}>Meals Total: <Peso value={totalMealsCost} /></Text>
            <Text style={styles.selLine}>Activities Total: <Peso value={totalActivitiesCost} /></Text>
            <Text style={[styles.selLine, { fontWeight: "800" }]}>
              Grand Total: <Peso value={Number(totalHotelCost + totalMealsCost + totalActivitiesCost)} />
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Save button fixed footer */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
          <Ionicons name="save-outline" size={18} color="white" />
          <Text style={styles.saveText}>Save Itinerary</Text>
        </TouchableOpacity>
      </View>

      <DestinationPreviewModal
          visible={previewModalVisible}
          onClose={() => setPreviewModalVisible(false)}
          destination={previewDestination}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 16, paddingTop: 12 },
  container: { padding: 16, paddingTop: 8, paddingBottom: 100 },
  screenTitle: { fontSize: 20, fontWeight: "700", color: "#111827" },
  tabBar: {
    flexDirection: "row",
    paddingHorizontal: 8,
    paddingVertical: 6,
    gap: 8,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: "#e5e7eb",
  },
  tabActive: {
    backgroundColor: "#111827",
  },
  tabText: { fontSize: 13, fontWeight: "700", color: "#111827" },
  tabTextActive: { color: "white" },
  section: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
  },
  sectionHeader: { flexDirection: "row", alignItems: "center", marginBottom: 8, gap: 8 },
  sectionTitle: { fontSize: 16, fontWeight: "700", color: "#1f2937", marginLeft: 6 },
  tier: { marginBottom: 8 },
  tierTitle: { fontSize: 13, fontWeight: "700", color: "#4b5563", marginBottom: 6 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    marginBottom: 8,
  },
  placeName: { fontSize: 15, fontWeight: "600", color: "#111827" },
  placeMeta: { fontSize: 12, color: "#6b7280", marginTop: 2 },
  peso: { fontWeight: "800", color: "#0f172a" },
  subNote: { fontSize: 11, color: "#6b7280" },
  note: { fontSize: 12, color: "#475569", marginBottom: 10 },
  rowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  smallLabel: { fontSize: 13, color: "#0f172a" },
  dayTabs: { flexDirection: "row", gap: 6, marginBottom: 8 },
  dayTab: { paddingVertical: 8, paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#e5e7eb" },
  dayTabActive: { backgroundColor: "#111827" },
  dayTabText: { fontSize: 12, fontWeight: "700", color: "#111827" },
  dayTabTextActive: { color: "white" },
  selLine: { fontSize: 13, color: "#0f172a", marginBottom: 2 },
  sbtn: { marginTop: 6, backgroundColor: "#111827", paddingVertical: 6, paddingHorizontal: 10, borderRadius: 8 },
  sbtnText: { color: "white", fontSize: 12, fontWeight: "700" },
  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 12,
    backgroundColor: "rgba(255,255,255,0.96)",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
  },
  saveBtn: {
    backgroundColor: "#0f37f1",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
  },
  saveText: { color: "white", fontSize: 15, fontWeight: "800" },
});