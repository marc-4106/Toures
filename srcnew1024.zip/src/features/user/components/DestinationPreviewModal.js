
import * as Location from "expo-location";
import React, { useEffect, useState } from "react";

import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import MapStyle from "../../../constant/MapStyle"; // ✅ adjust path if needed

export default function DestinationPreviewModal({
  visible,
  onClose,
  destination,
  onShowMap,
}) 

{
  if (!destination) return null;

  const {
    name,
    description,
    imageUrl,
    cityOrMunicipality,
    kind,
    Coordinates,
  } = destination;

  const hasCoords =
    Coordinates?.latitude != null && Coordinates?.longitude != null;

    const [userLocation, setUserLocation] = useState(null);

useEffect(() => {
  (async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") return;

    let location = await Location.getCurrentPositionAsync({});
    setUserLocation({
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    });
  })();
}, []);


  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose} // Android back button
    >
      <View style={styles.backdrop}>
        <View style={styles.card}>
          {/* Image */}
          {imageUrl ? (
            <Image
              source={{ uri: imageUrl }}
              style={styles.image}
              resizeMode="cover"
            />
          ) : (
            <View style={[styles.image, styles.imagePlaceholder]}>
              <Text style={styles.placeholderText}>No Image</Text>
            </View>
          )}

          {/* Info */}
          <View style={styles.content}>
            <Text style={styles.title}>{name}</Text>
            <Text style={styles.meta}>
              {(kind || "").toUpperCase()} • {cityOrMunicipality || "—"}
            </Text>
            {description ? (
              <Text style={styles.desc} numberOfLines={3}>
                {description}
              </Text>
            ) : null}
          </View>

          {/* Map Preview */}
          {hasCoords && (
            <View style={styles.mapPreview}>
              <MapView
                customMapStyle={MapStyle} 
                showsUserLocation={true}   
                style={{ flex: 1 }}
                pointerEvents="none"
                initialRegion={{
                  latitude: Number(Coordinates.latitude),
                  longitude: Number(Coordinates.longitude),
                  latitudeDelta: 0.01,
                  longitudeDelta: 0.01,
                }}
              >
                <Marker
                  coordinate={{
                    latitude: Number(Coordinates.latitude),
                    longitude: Number(Coordinates.longitude),
                  }}
                  title={name}
                />
              </MapView>
            </View>
          )}

          {/* Footer */}
          <View style={styles.footer}>
            <TouchableOpacity
              style={[styles.button, styles.closeBtn]}
              onPress={onClose}
            >
              <Text style={styles.buttonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  card: {
    width: "95%",
    maxWidth: 420,
    backgroundColor: "#fff",
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  image: {
    width: "100%",
    height: 180,
  },
  imagePlaceholder: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f3f4f6",
  },
  placeholderText: {
    color: "#9ca3af",
    fontWeight: "600",
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111827",
  },
  meta: {
    color: "#6b7280",
    fontSize: 13,
    marginTop: 3,
  },
  desc: {
    color: "#374151",
    fontSize: 14,
    marginTop: 6,
    lineHeight: 18,
  },
  mapPreview: {
    height: 300,
    marginHorizontal: 16,
    marginBottom: 12,
    borderRadius: 12,
    overflow: "hidden",
  },
  footer: {
    flexDirection: "row",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
  },
  button: {
    flex: 1,
    paddingVertical: 14,
    alignItems: "center",
  },
  closeBtn: { backgroundColor: "#ef4444" },
  mapBtn: { backgroundColor: "#0f37f1" },
  buttonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 15,
  },
});
