// src/features/user/logic/fuzzy/itinerary.js
import { mealCostWithHotel, hotelNightPrice, activityCost } from "./cost";
import { fuzzyScore, kmFromStart } from "./score";



// Candidate kinds
const HOTEL_KINDS = ["hotel", "resort"]; // allow resorts to act as lodging too
const ACTIVITY_KINDS = [
  "resort",
  "heritage",
  "mall",
  "pasalubong centers",
  "activity",
  "park",
  "museum",
  "beach",
];
const MEAL_PRIMARY_KINDS = ["restaurant"];

const toKey = (s) => String(s || "").toLowerCase().trim();
const pickTop = (arr, n) => arr.slice(0, Math.max(0, n));

function rankByKinds(places, prefs, kinds) {
  return places
    .filter((p) => kinds.includes(toKey(p.kind)))
    .map((p) => ({ place: p, score: fuzzyScore(p, prefs, kinds) }))
    .sort((a, b) => b.score - a.score);
}

function isMealCandidate(p) {
  const kind = toKey(p.kind);
  if (MEAL_PRIMARY_KINDS.includes(kind)) return true;

  // Allow non-restaurant places with food tags or explicit a-la-carte pricing
  const tags = Array.isArray(p.tags) ? p.tags.map(toKey) : [];
  const hasFoodTag = ["foodie", "cafe", "coffee", "market", "pasalubong"].some((t) =>
    tags.includes(t)
  );
  const ala = Number(p?.pricing?.mealPlan?.aLaCarteDefault ?? 0);
  return hasFoodTag || (Number.isFinite(ala) && ala > 0);
}

function rankMeals(places, prefs) {
  const pool = places.filter(isMealCandidate);
  return pool
    .map((p) => ({ place: p, score: fuzzyScore(p, prefs, MEAL_PRIMARY_KINDS) }))
    .sort((a, b) => b.score - a.score);
}

function bucketAlts(ranked, prefs) {
  const start = prefs?.startCity || null;

  const near = [];
  const moderate = [];
  for (const r of ranked) {
    const p = r.place;
    const dKm = kmFromStart(p, start);
    if (!Number.isFinite(dKm)) continue;
    if (dKm <= 15) near.push(r);
    else if (dKm <= 25) moderate.push(r);
  }

  near.sort((a,b) => b.score - a.score);
  moderate.sort((a,b) => b.score - a.score);

  const highly = near.slice(0, 5).map((r) => r.place);
  const considerable = moderate.slice(0, 15).map((r) => r.place);
  return { highly, considerable };
}

const withCost = (place, computedCost) =>
  place ? { ...place, computedCost: Number(computedCost) || 0 } : null;

/** A hotel night covers calendar days 1..nights (no hotel on day 0) */
const dayHasHotelCoverage = (dayIdx, nights) => dayIdx >= 1 && dayIdx <= nights;

/** Recompute meal costs for all days when accommodation changes */
export function recomputeAllMealCosts(plan) {
  const nights = Number(plan?.meta?.nights || 0);
  const hotel = plan?.accommodation?.selected || null;

  plan.days = plan.days.map((d, idx) => {
    const covered = dayHasHotelCoverage(idx, nights);

    const upd = (slot, key) =>
      slot
        ? {
            ...slot,
            selected: withCost(
              slot.selected,
              mealCostWithHotel(key, slot.selected, hotel, covered)
            ),
            alternatives: {
              highly: (slot.alternatives?.highly || []).map((p) =>
                withCost(p, mealCostWithHotel(key, p, hotel, covered))
              ),
              considerable: (slot.alternatives?.considerable || []).map((p) =>
                withCost(p, mealCostWithHotel(key, p, hotel, covered))
              ),
            },
          }
        : slot;

    return {
      ...d,
      breakfast: upd(d.breakfast, "breakfast"),
      lunch: upd(d.lunch, "lunch"),
      dinner: upd(d.dinner, "dinner"),
    };
  });

  return plan;
}

export function buildItinerary(places, prefs) {
  // Normalize serializable dates
  const startISO = new Date(prefs.startDate).toISOString();
  const endISO = new Date(prefs.endDate).toISOString();

  const start = new Date(startISO);
  const end = new Date(endISO);
  const ONE = 24 * 3600 * 1000;
  const nights = Math.max(0, Math.round((end.setHours(0,0,0,0) - start.setHours(0,0,0,0)) / ONE));
  const days = nights + 1;

  // Rankings
  const rankedHotels = rankByKinds(places, prefs, HOTEL_KINDS);
  const rankedActivities = rankByKinds(places, prefs, ACTIVITY_KINDS);
  const rankedMeals = rankMeals(places, prefs);

  const hotelAlts = bucketAlts(rankedHotels, prefs);
  const actAlts = bucketAlts(rankedActivities, prefs);
  const mealAlts = bucketAlts(rankedMeals, prefs);

  const topHotel = rankedHotels[0]?.place || null;

  // ===== Accommodation (separate card, whole-stay) =====
  const nightly = topHotel ? hotelNightPrice(topHotel) : 0;
  const accommodation = {
    nights,
    selected: topHotel ? { ...topHotel, nightlyPrice: nightly, totalCost: nights * nightly } : null,
    alternatives: {
      highly: hotelAlts.highly.map((p) => ({
        ...p,
        nightlyPrice: hotelNightPrice(p),
        totalCost: nights * hotelNightPrice(p),
      })),
      considerable: hotelAlts.considerable.map((p) => ({
        ...p,
        nightlyPrice: hotelNightPrice(p),
        totalCost: nights * hotelNightPrice(p),
      })),
    },
  };

  // ===== Daily plan =====
  const outDays = [];
  for (let d = 0; d < days; d++) {
    const date = new Date(start);
    date.setDate(start.getDate() + d);

    const covered = dayHasHotelCoverage(d, nights);

    // Meals: present on every day (Day 1 included)
    const breakfastPick = rankedMeals[0]?.place || null;
    const lunchPick = rankedMeals[1]?.place || rankedMeals[0]?.place || null;
    const dinnerPick = rankedMeals[2]?.place || rankedMeals[1]?.place || rankedMeals[0]?.place || null;

    const breakfastRow = {
      selected: withCost(breakfastPick, mealCostWithHotel("breakfast", breakfastPick, accommodation.selected, covered)),
      alternatives: {
        highly: mealAlts.highly.map((p) => withCost(p, mealCostWithHotel("breakfast", p, accommodation.selected, covered))),
        considerable: mealAlts.considerable.map((p) => withCost(p, mealCostWithHotel("breakfast", p, accommodation.selected, covered))),
      },
    };

    const lunchRow = {
      selected: withCost(lunchPick, mealCostWithHotel("lunch", lunchPick, accommodation.selected, covered)),
      alternatives: {
        highly: mealAlts.highly.map((p) => withCost(p, mealCostWithHotel("lunch", p, accommodation.selected, covered))),
        considerable: mealAlts.considerable.map((p) => withCost(p, mealCostWithHotel("lunch", p, accommodation.selected, covered))),
      },
    };

    const dinnerRow = {
      selected: withCost(dinnerPick, mealCostWithHotel("dinner", dinnerPick, accommodation.selected, covered)),
      alternatives: {
        highly: mealAlts.highly.map((p) => withCost(p, mealCostWithHotel("dinner", p, accommodation.selected, covered))),
        considerable: mealAlts.considerable.map((p) => withCost(p, mealCostWithHotel("dinner", p, accommodation.selected, covered))),
      },
    };

    // Activities (morning, afternoon, night) each is an array (multi-line capable)
    const morningPick = rankedActivities[0]?.place || null;
    const afternoonPick = rankedActivities[1]?.place || rankedActivities[0]?.place || null;
    const nightPick = rankedActivities[2]?.place || rankedActivities[1]?.place || rankedActivities[0]?.place || null;

    const morningRow = [
      {
        selected: withCost(morningPick, activityCost(morningPick)),
        alternatives: {
          highly: actAlts.highly.map((p) => withCost(p, activityCost(p))),
          considerable: actAlts.considerable.map((p) => withCost(p, activityCost(p))),
        },
      },
    ];

    const afternoonRow = [
      {
        selected: withCost(afternoonPick, activityCost(afternoonPick)),
        alternatives: {
          highly: actAlts.highly.map((p) => withCost(p, activityCost(p))),
          considerable: actAlts.considerable.map((p) => withCost(p, activityCost(p))),
        },
      },
    ];

    const nightRow = [
      {
        selected: withCost(nightPick, activityCost(nightPick)),
        alternatives: {
          highly: actAlts.highly.map((p) => withCost(p, activityCost(p))),
          considerable: actAlts.considerable.map((p) => withCost(p, activityCost(p))),
        },
      },
    ];

    outDays.push({
      date: date.toISOString().slice(0, 10),
      breakfast: breakfastRow,
      morning: morningRow,
      lunch: lunchRow,
      afternoon: afternoonRow,
      dinner: dinnerRow,
      night: nightRow, // NEW
    });
  }

  const plan = {
    meta: {
      ...prefs,
      startDate: startISO,
      endDate: endISO,
      nights,
      generatedAt: new Date().toISOString(),
    },
    accommodation,
    days: outDays,

    // NEW: keep global fallbacks so we can add activities even if a slot is empty
    alternatives: {
      meal: mealAlts,
      activity: actAlts,
    },
  };

  // Ensure meal costs reflect current accommodation inclusions
  return recomputeAllMealCosts(plan);
}
