// ----------------------------------------------------------------------
// 1. BASIC MEMBERSHIP HELPERS

const clamp01 = (x) => Math.max(0, Math.min(1, x));

/** Triangular membership */
function tri(x, a, b, c) {
  if (x <= a || x >= c) return 0;
  if (x === b) return 1;
  return x < b ? (x - a) / (b - a) : (c - x) / (c - b);
}

/** Trapezoidal membership */
function trap(x, a, b, c, d) {
  if (x <= a || x >= d) return 0;
  if (x >= b && x <= c) return 1;
  if (x > a && x < b) return (x - a) / (b - a);
  return (d - x) / (d - c);
}

// ----------------------------------------------------------------------
// 2. FUZZY SET CONSTANTS

const DIST = {
  near: (d) => trap(d, 0, 0, 5, 12),
  mid: (d) => tri(d, 8, 20, 40),
  far: (d) => trap(d, 30, 60, 999, 999),
};

const PRICE = {
  cheap: (p) => trap(p, 0, 0, 400, 700),
  moderate: (p) => tri(p, 500, 900, 1500),
  pricey: (p) => trap(p, 1200, 2000, 99999, 99999),
};

const INTEREST = {
  low: (x) => trap(x, 0.0, 0.0, 0.25, 0.4),
  mid: (x) => tri(x, 0.2, 0.5, 0.8),
  high: (x) => trap(x, 0.6, 0.75, 1.0, 1.0),
};

// ----------------------------------------------------------------------
// 3. CORE UTILITIES

/** Interest fit = Jaccard over tags, with fallback */
function interestFit(placeTags, desired) {
  const A = new Set((placeTags || []).map(String));
  const B = new Set((desired || []).map(String));

  // ✅ Neutral fallback when no tags or no interests
  if (A.size === 0 || B.size === 0) return 0.4;

  let inter = 0;
  B.forEach((x) => {
    if (A.has(x)) inter += 1;
  });
  const union = new Set([...A, ...B]).size;
  return inter / union; // 0..1
}

/** Haversine formula for distance in kilometers. */
export function kmFromStart(place, start) {
  const lat1 = Number(start?.lat),
    lon1 = Number(start?.lng);
  const lat2 = Number(
    place?.Coordinates?.latitude ?? place?.lat ?? place?.latitude
  );
  const lon2 = Number(
    place?.Coordinates?.longitude ?? place?.lng ?? place?.longitude
  );

  if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) return 1e9;

  const toRad = (x) => (x * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/** Pulls ONE price representative depending on context. */
function priceForContext(place, targetKinds) {
  const pricing = place.pricing || {};
  const kind = String(place.kind || "").toLowerCase();

  const nightly = Number(pricing?.lodging?.nightly ?? NaN);
  const meal = Number(pricing?.aLaCarte?.default ?? NaN);
  const dayUse = Number(pricing?.dayUse?.fee ?? NaN);

  if (kind === "hotel" || kind === "resort" || targetKinds?.includes("hotel")) {
    if (Number.isFinite(nightly)) return nightly;
  }
  if (kind === "restaurant" || targetKinds?.includes("restaurant")) {
    if (Number.isFinite(meal)) return meal;
  }
  if (Number.isFinite(dayUse)) return dayUse;
  if (Number.isFinite(meal)) return meal;
  if (Number.isFinite(nightly)) return nightly;
  return Number(place.idealCost ?? 0);
}

// ----------------------------------------------------------------------
// 4. INFERENCE HELPERS & DEFUZZIFICATION

function ruleOutput(label) {
  const LUT = {
    excellent: 95,
    good: 80,
    fair: 60,
    poor: 35,
    bad: 10,
  };
  return LUT[label] ?? 50;
}

function min3(a, b, c) {
  return Math.min(a, Math.min(b, c));
}
function min2(a, b) {
  return Math.min(a, b);
}

// Sugeno-style: sum(w_i * z_i) / sum(w_i)
function defuzzify(rules) {
  let num = 0,
    den = 0;
  for (const { w, z } of rules) {
    if (w > 0) {
      num += w * z;
      den += w;
    }
  }
  return den > 0 ? num / den : 0;
}

// ----------------------------------------------------------------------
// 5. MAIN SCORING FUNCTION

export function fuzzyScore(place, preferences, targetKinds) {
  const start = preferences?.startCity;
  const maxDist = Number(preferences?.constraints?.maxDistanceKm || 0);

  // Inputs
  const dKm = kmFromStart(place, start);
  const price = priceForContext(place, targetKinds);
  const iFit = interestFit(
    place?.tags || place?.categories,
    preferences?.interests
  );

  // Fuzzify
  const D = {
    near: DIST.near(dKm),
    mid: DIST.mid(dKm),
    far: DIST.far(dKm),
  };
  const P = {
    cheap: PRICE.cheap(price),
    moderate: PRICE.moderate(price),
    pricey: PRICE.pricey(price),
  };
  const I = {
    low: INTEREST.low(iFit),
    mid: INTEREST.mid(iFit),
    high: INTEREST.high(iFit),
  };

  const rules = [];

  // === NEAR DISTANCE RULES ===
  rules.push({ w: min2(D.near, I.high), z: ruleOutput("excellent") });
  rules.push({ w: min2(D.near, I.mid), z: ruleOutput("good") });
  rules.push({ w: min2(D.near, I.low), z: ruleOutput("fair") });
  rules.push({ w: D.near * P.cheap, z: ruleOutput("good") });
  rules.push({ w: D.near * P.pricey, z: ruleOutput("fair") });

  // === MID DISTANCE RULES ===
  rules.push({ w: min3(D.mid, I.high, P.cheap), z: ruleOutput("good") });
  rules.push({ w: min3(D.mid, I.high, P.moderate), z: ruleOutput("fair") });
  rules.push({ w: min3(D.mid, I.mid, P.cheap), z: ruleOutput("fair") });

  // ✅ NEW fallback for mid-distance even without interest
  rules.push({
    w: D.mid * P.cheap * 0.7, // weaker weight
    z: ruleOutput("fair"),
  });

  // === FAR DISTANCE RULES ===
  rules.push({ w: D.far * I.high, z: ruleOutput("fair") });
  rules.push({ w: D.far * I.mid, z: ruleOutput("poor") });
  rules.push({ w: D.far * I.low, z: ruleOutput("bad") });

  // === PENALTY RULES ===
  rules.push({ w: D.far * P.pricey, z: ruleOutput("bad") });
  rules.push({ w: I.low, z: ruleOutput("bad") });

  // Hard distance cap
  if (maxDist > 0 && Number.isFinite(dKm)) {
    const capFactor = clamp01(1 - dKm / (maxDist * 1.5));
    for (const r of rules) r.w *= capFactor;
  }

  // ✅ Fallback safeguard: ensure nonzero baseline
  if (rules.every((r) => r.w === 0)) {
    rules.push({ w: 1, z: ruleOutput("fair") });
  }

  // Defuzzify
  const score100 = defuzzify(rules);

  // Debug (optional)
   //console.log({ name: place.name, dKm, price, iFit, D, P, I, score100 });

  return score100 / 100;
}
