import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Keyboard,
  Alert,
} from "react-native";
import MapView, { Marker, Polyline } from "react-native-maps";
import Constants from "expo-constants";
import * as Location from "expo-location";
import { collection, getDocs, query, where } from "firebase/firestore";
import { useRoute, useNavigation } from "@react-navigation/native";
import { db } from "../../../services/firebaseConfig";
import  MapStyle  from "../../../constant/MapStyle";
import { haversineKm, formatKm } from "../../recommender/distance";

const NEAR_ME_DISTANCE_KM = 5;
const MAP_API_KEY = Constants.expoConfig.extra?.googleMapsApiKey;

const BACOLOD_REGION = {
  latitude: 10.6667,
  longitude: 122.95,
  latitudeDelta: 0.0922,
  longitudeDelta: 0.0421,
};

// 🎨 Pin colors per kind (lowercase keys)
const KIND_COLORS = {
  hotel: "#7C3AED",      // violet
  restaurant: "#F97316", // orange
  resort: "#14B8A6",     // teal
  mall: "#EF4444",       // red
  heritage: "#22C55E",   // green
  default: "#3B82F6",    // blue (fallback)
};

const normKind = (k) => (k ? String(k).toLowerCase() : "");

export default function UserExploreScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const mapRef = useRef(null);

  const [mapRegion, setMapRegion] = useState(BACOLOD_REGION);
  const [userLocation, setUserLocation] = useState(null);
  const [destinations, setDestinations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState(null);

  const [selectedDestination, setSelectedDestination] = useState(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState(null);

  // 1) User location
  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied. Showing Bacolod default.");
        setIsLoading(false);
        return;
      }
      let location = await Location.getCurrentPositionAsync({});
      const currentLoc = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(currentLoc);
      setMapRegion({ ...currentLoc, latitudeDelta: 0.0922, longitudeDelta: 0.0421 });
      setIsLoading(false);
    })();
  }, []);

  // 2) Fetch destinations (not archived)
  useEffect(() => {
    const fetchDestinations = async () => {
      try {
        const q = query(collection(db, "destinations"), where("isArchived", "==", false));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map((doc) => {
          const d = doc.data();
          const kind = normKind(d.kind);
          return {
            id: doc.id,
            ...d,
            kind,
            Coordinates: d.Coordinates || { latitude: 0, longitude: 0 },
            tags: Array.isArray(d.tags) ? d.tags : Array.isArray(d.categories) ? d.categories : [],
          };
        });
        setDestinations(data);
      } catch (e) {
        console.error("Error fetching destinations:", e);
        setErrorMsg("Failed to load destinations for the map.");
      }
    };
    fetchDestinations();
  }, []);

  // 3) Directions polyline via Google Directions API
  const getRoute = async (destinationCoords) => {
    if (!userLocation) {
      Alert.alert("Error", "Cannot get directions: Your location is unknown.");
      return;
    }
    const origin = `${userLocation.latitude},${userLocation.longitude}`;
    const destination = `${destinationCoords.latitude},${destinationCoords.longitude}`;
    const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${destination}&key=${MAP_API_KEY}`;

    try {
      const response = await fetch(url);
      const json = await response.json();

      if (json.routes.length) {
        const points = json.routes[0].overview_polyline.points;

        const decode = (t) => {
          let pts = [];
          let index = 0, lat = 0, lng = 0;
          while (index < t.length) {
            let b, shift = 0, result = 0;
            do { b = t.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
            let dlat = (result & 1) ? ~(result >> 1) : (result >> 1);
            lat += dlat;

            shift = 0; result = 0;
            do { b = t.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
            let dlng = (result & 1) ? ~(result >> 1) : (result >> 1);
            lng += dlng;

            pts.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
          }
          return pts;
        };

        const coords = decode(points);
        setRouteCoordinates(coords);

        if (mapRef.current) {
          mapRef.current.fitToCoordinates(
            [userLocation, destinationCoords],
            { edgePadding: { top: 50, right: 50, bottom: 50, left: 50 }, animated: true }
          );
        }
      } else {
        Alert.alert("Routing Error", "Could not find a route between your location and the destination.");
        setRouteCoordinates(null);
      }
    } catch (e) {
      console.error("Error fetching route:", e);
      Alert.alert("API Error", "Failed to fetch directions. Check network or API key.");
      setRouteCoordinates(null);
    }
  };

  // 4) Search / filter
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("All");

  // 🔎 UPDATED: search matches name + kind + tags
  const filteredDestinations = destinations.filter((dest) => {
    const q = searchTerm.trim().toLowerCase();
    const matchesSearch =
      q.length === 0
        ? true
        : ((dest.name || "").toLowerCase().includes(q) ||
           (dest.kind || "").toLowerCase().includes(q) ||
           (Array.isArray(dest.tags) ? dest.tags.join(" ") : "").toLowerCase().includes(q));

    if (KIND_COLORS[filterType]) {
    return !dest.isArchived && dest.kind === filterType && matchesSearch;
      }

    if (filterType === "All") return !dest.isArchived && matchesSearch;

    if (filterType === "Near Me" && userLocation) {
      const dist = haversineKm(
        userLocation.latitude,
        userLocation.longitude,
        dest.Coordinates.latitude,
        dest.Coordinates.longitude
      );
      return dist <= NEAR_ME_DISTANCE_KM && !dest.isArchived && matchesSearch;
    }

    if (filterType === "Search") return !dest.isArchived && matchesSearch;

    return false;

  });

  const handleFilterChange = (newFilterType) => {
    Keyboard.dismiss();
    setFilterType(newFilterType);
    if (newFilterType === "Near Me" && !userLocation) {
      Alert.alert("Location Required", 'Please enable location services to use the "Near Me" filter.');
    }
  };

  const handleMarkerPress = (destination) => {
    setSelectedDestination(destination);
    setRouteCoordinates(null);
    setIsModalVisible(true);
  };

  const handleDirectionsButton = () => {
    if (selectedDestination) {
      setIsModalVisible(false);
      getRoute(selectedDestination.Coordinates);
    }
  };

  // 5) 🔎 Focus when coming from other screens
  const focusOnPlace = async ({ id, name, latitude, longitude, showRoute = false }) => {
    const dest = {
      id: id || `${latitude},${longitude}`,
      name: name || "Selected place",
      Coordinates: { latitude, longitude },
    };

    if (mapRef.current && latitude && longitude) {
      mapRef.current.animateToRegion(
        { latitude, longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 },
        400
      );
    }

    setSelectedDestination(dest);
    setIsModalVisible(true);

    if (showRoute && latitude && longitude) {
      await getRoute({ latitude, longitude });
    }
  };

  useEffect(() => {
    const f = route.params?.focus;
    if (!f) return;

    const lat = Number(f.latitude);
    const lng = Number(f.longitude);
    if (Number.isFinite(lat) && Number.isFinite(lng)) {
      focusOnPlace({
        id: f.id,
        name: f.name,
        latitude: lat,
        longitude: lng,
        showRoute: !!f.showRoute,
      });
    }
    navigation.setParams({ focus: undefined });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route.params?.focus]);

  const modalDistanceKm =
    selectedDestination && userLocation
      ? haversineKm(
          userLocation.latitude,
          userLocation.longitude,
          selectedDestination.Coordinates.latitude,
          selectedDestination.Coordinates.longitude
        )
      : null;

  return (
    <View style={styles.container}>
      {/* Search & Filter */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search destinations on map..."
          value={searchTerm}
          onChangeText={setSearchTerm}
          onSubmitEditing={() => handleFilterChange("Search")}
        />
        <TouchableOpacity
          style={[styles.filterButton, filterType === "Near Me" && styles.activeFilter]}
          onPress={() => handleFilterChange("Near Me")}
        >
          <Text style={styles.filterButtonText}>Near Me</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterButton, filterType === "All" && styles.activeFilter]}
          onPress={() => handleFilterChange("All")}
        >
          <Text style={styles.filterButtonText}>All</Text>
        </TouchableOpacity>
      </View>
      {/* Legend (top-left corner) */}
      <View style={styles.legendContainer}>
        {Object.entries(KIND_COLORS).map(([key, color]) => {
          if (key === "default") return null;
          const isActive = filterType === key;
          return (
            <TouchableOpacity
              key={key}
              style={[
                styles.legendItem,
                { backgroundColor: isActive ? "#e0e7ff" : "#fff" },
              ]}
              onPress={() => {
                if (filterType === key) setFilterType("All");
                else setFilterType(key);
              }}
            >
              <View style={[styles.legendColor, { backgroundColor: color }]} />
              <Text style={styles.legendText}>{key.charAt(0).toUpperCase() + key.slice(1)}</Text>
            </TouchableOpacity>
          );
        })}
      </View>


      {/* Map */}
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={BACOLOD_REGION}
        region={mapRegion}
        onRegionChangeComplete={setMapRegion}
        customMapStyle={MapStyle}
        showsUserLocation={true}     // native blue dot
        showsMyLocationButton={true}
      >
        {/* Destination markers */}
        {filteredDestinations.map((dest) => {
          const kindKey = normKind(dest.kind);
          const pinColor = KIND_COLORS[kindKey] || KIND_COLORS.default;
          return (
            <Marker
              key={dest.id}
              coordinate={{
                latitude: dest.Coordinates.latitude,
                longitude: dest.Coordinates.longitude,
              }}
              title={dest.name}
              description={dest.kind ? dest.kind : undefined}
              onPress={() => handleMarkerPress(dest)}
              pinColor={pinColor}
            />
          );
        })}

        {/* Route polyline */}
        {routeCoordinates && routeCoordinates.length > 0 && (
          <Polyline coordinates={routeCoordinates} strokeWidth={4} strokeColor="#0f37f1" />
        )}
      </MapView>

      {/* Loading / Error */}
      {(isLoading || errorMsg) && (
        <View style={styles.overlay}>
          {isLoading ? (
            <ActivityIndicator size="large" color="#0f37f1" />
          ) : (
            <Text style={styles.errorText}>{errorMsg}</Text>
          )}
        </View>
      )}

      {/* Bottom Sheet Modal */}
      {selectedDestination && (
        <View
          style={[styles.modalOverlay, { display: isModalVisible ? "flex" : "none" }]}
          pointerEvents={isModalVisible ? "auto" : "none"}
        >
          <TouchableOpacity
            style={styles.modalBackground}
            activeOpacity={1}
            onPress={() => setIsModalVisible(false)}
          />
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>{selectedDestination.name}</Text>

            <Text style={styles.modalMeta}>
              Distance: {modalDistanceKm == null ? "—" : `${formatKm(modalDistanceKm)} away`}
            </Text>

            <View style={styles.modalActionRow}>
              <TouchableOpacity
                style={[styles.directionButton, styles.directionButtonPrimary]}
                onPress={handleDirectionsButton}
              >
                <Text style={styles.directionButtonText}>Get Directions</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.closeButton} onPress={() => setIsModalVisible(false)}>
              <Text style={styles.closeButtonText}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8f9fa" },
  searchContainer: {
    padding: 10, backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#eee",
    flexDirection: "row", alignItems: "center", zIndex: 10,
  },
  searchInput: {
    flex: 1, height: 40, borderWidth: 1, borderColor: "#ddd", borderRadius: 20,
    paddingHorizontal: 15, marginRight: 10, fontSize: 16,
  },
  filterButton: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: "#eee", marginLeft: 5,
  },
  activeFilter: { backgroundColor: "#6a80e2ff" },
  filterButtonText: { color: "#000000ff", fontWeight: "600" },
  map: { flex: 1, zIndex: 1 },
  overlay: {
    position: "absolute", top: 0, left: 0, right: 0, bottom: 0, justifyContent: "center",
    alignItems: "center", backgroundColor: "rgba(255, 255, 255, 0.7)", zIndex: 2,
  },
  errorText: { marginTop: 10, color: "red", textAlign: "center" },

  // Modal
  modalOverlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 50, zIndex: 10 },
  modalBackground: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.5)" },
  modalContainer: {
    position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "white",
    borderTopLeftRadius: 15, borderTopRightRadius: 15, padding: 20, paddingBottom: 40, zIndex: 5,
    shadowColor: "#000", shadowOffset: { width: 0, height: -3 }, shadowOpacity: 0.15, shadowRadius: 5, elevation: 15,
  },
  modalTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 5, color: "#333" },
  modalMeta: { fontSize: 14, color: "#0f172a", marginBottom: 10, fontWeight: "600" },
  modalActionRow: { flexDirection: "row", justifyContent: "space-between", gap: 10 },
  directionButton: { padding: 12, borderRadius: 8, alignItems: "center", flex: 1 },
  directionButtonPrimary: { backgroundColor: "#0f37f1" },
  directionButtonText: { color: "white", fontSize: 16, fontWeight: "bold" },
  closeButton: { position: "absolute", top: 10, right: 10, padding: 5, zIndex: 6 },
  closeButtonText: { fontSize: 20, color: "#333", fontWeight: "bold" },
  legendContainer: {
  position: "absolute",
  top: 70, // adjust if needed
  left: 10,
  backgroundColor: "rgba(255,255,255,0.9)",
  borderRadius: 10,
  padding: 8,
  zIndex: 20,
  elevation: 5,
},
legendItem: {
  flexDirection: "row",
  alignItems: "center",
  marginBottom: 6,
  paddingVertical: 4,
  paddingHorizontal: 6,
  borderRadius: 8,
},
legendColor: {
  width: 14,
  height: 14,
  borderRadius: 3,
  marginRight: 8,
},
legendText: { color: "#111", fontWeight: "600", textTransform: "capitalize" },

});
