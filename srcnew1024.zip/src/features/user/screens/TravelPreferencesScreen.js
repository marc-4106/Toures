// src/features/user/screens/TravelPreferencesScreen.js
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Platform,
  SafeAreaView,
  KeyboardAvoidingView,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "../../../services/firebaseConfig";
import { buildItinerary } from "../logic/fuzzy/itinerary";
import * as Location from "expo-location";


// Small helper to format a Date like "Oct 6, 2025"
const formatDate = (d) =>
  new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(d);

// Negros Occidental — Cities & Municipalities (with coords)
const START_CITIES = [
  { label: "Bacolod", lat: 10.6767, lng: 122.9511 },
  { label: "Bago", lat: 10.5333, lng: 122.8333 },
  { label: "Cadiz", lat: 10.9465, lng: 123.288 },
  { label: "Escalante", lat: 10.8403, lng: 123.4999 },
  { label: "Himamaylan", lat: 10.0988, lng: 122.8706 },
  { label: "Kabankalan", lat: 9.9833, lng: 122.8167 },
  { label: "La Carlota", lat: 10.4242, lng: 122.9213 },
  { label: "Sagay", lat: 10.9447, lng: 123.4242 },
  { label: "San Carlos", lat: 10.4833, lng: 123.4167 },
  { label: "Silay", lat: 10.753, lng: 122.9674 },
  { label: "Sipalay", lat: 9.7513, lng: 122.4048 },
  { label: "Talisay", lat: 10.737, lng: 122.9671 },
  { label: "Victorias", lat: 10.9012, lng: 123.0701 },
  { label: "Binalbagan", lat: 10.2, lng: 122.8667 },
  { label: "Calatrava", lat: 10.6, lng: 123.5 },
  { label: "Candoni", lat: 9.8167, lng: 122.6333 },
  { label: "Cauayan", lat: 9.9667, lng: 122.5167 },
  { label: "Don Salvador Benedicto", lat: 10.5333, lng: 123.2833 },
  { label: "E.B. Magalona", lat: 10.9, lng: 122.9667 },
  { label: "Hinigaran", lat: 10.2667, lng: 122.85 },
  { label: "Hinoba-an", lat: 9.5833, lng: 122.4667 },
  { label: "Ilog", lat: 10.0, lng: 122.7667 },
  { label: "Isabela", lat: 10.2, lng: 122.9833 },
  { label: "La Castellana", lat: 10.3167, lng: 123.0333 },
  { label: "Manapla", lat: 10.95, lng: 123.1333 },
  { label: "Moises Padilla", lat: 10.2667, lng: 123.0833 },
  { label: "Murcia", lat: 10.6, lng: 123.0333 },
  { label: "Pontevedra", lat: 10.3667, lng: 122.8667 },
  { label: "Pulupandan", lat: 10.5167, lng: 122.8 },
  { label: "Salvador Benedicto", lat: 10.5833, lng: 123.2167 },
  { label: "San Enrique", lat: 10.4333, lng: 122.85 },
  { label: "Toboso", lat: 10.7167, lng: 123.5167 },
  { label: "Valladolid", lat: 10.4667, lng: 122.8167 },
];


// Interests (tags) — include 'foodie' because your logic checks it
const INTERESTS = [
  "culture",
  "shopping",
  "adventure",
  "activity",
  "relaxation",
  "nature",
  "beach",
  "indoor",
  "outdoor",
  "night",
  "day",
  "family_friendly",
  "scenic",
  "history",
  "photography",
  "budget",
  "premium",
  "city",
  "park",
  "foodie",
];

// Preferred distance from start city (reference-only)
const DISTANCE_OPTIONS = [
  { key: "near", label: "Near (within city) — ≤ 5 km", near: 5, moderate: 10, max: 5 },
  { key: "moderate", label: "Moderate (up to ~3 municipalities) — ≤ 30 km", near: 5, moderate: 30, max: 30 },
  { key: "far", label: "Far (beyond nearby municipalities) — > 30 km", near: 5, moderate: 30, max: 60 },
];


export default function TravelPreferencesScreen() {
  const navigation = useNavigation();

  // Use index to pick from START_CITIES
  const [startCityIdx, setStartCityIdx] = useState(0);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date(Date.now() + 24 * 3600 * 1000));
  const [showStart, setShowStart] = useState(false);
  const [showEnd, setShowEnd] = useState(false);
  // ✅ New: Use current location toggle and data
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);

  // Dropdown selections
  const [dailyBudgetIdx, setDailyBudgetIdx] = useState(2); // default ₱1,000–₂,000
// default Moderate


  const [maxBudget, setMaxBudget] = useState("");
  const [maxDistanceKm, setMaxDistanceKm] = useState("10");
  const [nearDistanceKm, setNearDistanceKm] = useState("");
  const [moderateDistanceKm, setModerateDistanceKm] = useState("");

  const [selectedInterests, setSelectedInterests] = useState(new Set(["culture", "foodie"]));
  const [loading, setLoading] = useState(false);

  const toggleInterest = (key) => {
    setSelectedInterests((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const submit = async () => {
    try {
      setLoading(true);

      // Fetch all non-archived destinations\n
      // Derive budget and distance from dropdowns
                  
                        
      const snap = await getDocs(query(collection(db, "destinations"), where("isArchived", "==", false)));
      const places = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

     const preferences = {
        startCity: useCurrentLocation && currentLocation
          ? currentLocation
          : START_CITIES[startCityIdx],
          startDate,
          endDate,
          maxBudget: Number(maxBudget) || 0,
          interests: Array.from(selectedInterests),
          reference: { preferredDailyBudgetRange: null },
      };


      const plan = buildItinerary(places, preferences);
      navigation.navigate("ItineraryPreview", { plan });
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "Failed to generate itinerary.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 80 : 0}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: 120 }]}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={styles.title}>New Itinerary</Text>
          <Text style={styles.subtitle}>Tell us your preferences and we’ll craft a plan.</Text>

          {/* Start City */}
          <Text style={styles.label}>Starting City</Text>
          <View style={styles.pickerWrap}>
            <Picker selectedValue={startCityIdx} onValueChange={(v) => setStartCityIdx(v)}>
              {START_CITIES.map((c, idx) => (
                <Picker.Item key={c.label} label={c.label} value={idx} />
              ))}
            </Picker>
          </View>

          {/* ✅ Option to use current location */}
        <TouchableOpacity
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginTop: 8,
            backgroundColor: useCurrentLocation ? "#dbeafe" : "#f1f5f9",
            paddingVertical: 10,
            paddingHorizontal: 12,
            borderRadius: 10,
          }}
          onPress={async () => {
            if (useCurrentLocation) {
              setUseCurrentLocation(false);
              setCurrentLocation(null);
              return;
            }

            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== "granted") {
                Alert.alert("Permission denied", "Location access is required to use current location.");
                return;
              }

              const pos = await Location.getCurrentPositionAsync({});
              setCurrentLocation({
                label: "Current Location",
                lat: pos.coords.latitude,
                lng: pos.coords.longitude,
              });
              setUseCurrentLocation(true);
            } catch (e) {
              console.error(e);
              Alert.alert("Error", "Unable to fetch current location.");
            }
          }}
        >
  <Ionicons
    name={useCurrentLocation ? "location" : "location-outline"}
    size={18}
    color={useCurrentLocation ? "#0f37f1" : "#475569"}
    style={{ marginRight: 8 }}
  />
  <Text style={{ fontWeight: "700", color: "#0f172a" }}>
    {useCurrentLocation ? "Using current location" : "Use my current location"}
  </Text>
</TouchableOpacity>


          {/* Date Range */}
          <Text style={styles.label}>Date Range</Text>
          <View style={styles.row}>
            <TouchableOpacity style={[styles.dateBtn]} onPress={() => setShowStart(true)}>
              <Text style={styles.dateText}>{formatDate(startDate)}</Text>
            </TouchableOpacity>
            <Text style={{ marginHorizontal: 8, color: "#64748b" }}>→</Text>
            <TouchableOpacity style={[styles.dateBtn]} onPress={() => setShowEnd(true)}>
              <Text style={styles.dateText}>{formatDate(endDate)}</Text>
            </TouchableOpacity>
          </View>

          {showStart && (
            <DateTimePicker
              value={startDate}
              mode="date"
              display={Platform.OS === "ios" ? "inline" : "default"}
              onChange={(_, d) => {
                setShowStart(false);
                if (d) {
                  setStartDate(d);
                  if (d > endDate) setEndDate(new Date(d.getTime() + 24 * 3600 * 1000));
                }
              }}
            />
          )}
          {showEnd && (
            <DateTimePicker
              value={endDate}
              mode="date"
              display={Platform.OS === "ios" ? "inline" : "default"}
              onChange={(_, d) => {
                setShowEnd(false);
                if (d) setEndDate(d);
              }}
              minimumDate={startDate}
            />
          )}


{/* Budget */}
<Text style={styles.label}>Max Budget (₱)</Text>
<TextInput
  style={styles.input}
  placeholder="e.g., 5000"
  keyboardType="number-pad"
  value={String(maxBudget)}
  onChangeText={setMaxBudget}
/>
{/* Interests */}
{/* Interests */}

          <Text style={styles.label}>Interests</Text>
          <View style={styles.tagsWrap}>
            {INTERESTS.map((t) => {
              const active = selectedInterests.has(t);
              return (
                <TouchableOpacity
                  key={t}
                  onPress={() => toggleInterest(t)}
                  style={[
                    styles.tag,
                    { backgroundColor: active ? "#d1fae5" : "transparent", borderColor: active ? "#10b981" : "#cbd5e1" },
                  ]}
                >
                  <View style={[styles.checkbox, active && styles.checkboxChecked]} />
                  <Text style={{ color: active ? "#065f46" : "#0f172a" }}>{t}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </ScrollView>

        {/* FIXED BOTTOM ACTION BAR (no tabBarHeight dependency) */}
        <View style={styles.footerFixed}>
          <TouchableOpacity style={[styles.btn, styles.btnGhost]} onPress={() => navigation.goBack()} disabled={loading}>
            <Text style={[styles.btnText, { color: "#111" }]}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.btn, styles.btnPrimary]} onPress={submit} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="sparkles-outline" size={18} color="#fff" />
                <Text style={styles.btnText}>Start Fuzzy</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff" },
  scrollContent: { padding: 16 },

  title: { fontSize: 22, fontWeight: "800", color: "#0f172a" },
  subtitle: { color: "#475569", marginBottom: 12, marginTop: 4 },

  label: { fontWeight: "700", color: "#0f172a", marginTop: 10, marginBottom: 6 },
  pickerWrap: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#f8fafc",
  },
  row: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  dateBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
    backgroundColor: "#f8fafc",
  },
  dateText: { fontWeight: "600", color: "#0f172a" },

  input: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#f8fafc",
    color: "#0f172a",
  },

  tagsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  tag: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginRight: 6,
    marginBottom: 6,
  },
  checkbox: {
    width: 16,
    height: 16,
    borderWidth: 2,
    borderColor: "#9ca3af",
    borderRadius: 3,
    backgroundColor: "transparent",
    marginRight: 8,
  },
  checkboxChecked: { borderColor: "#10b981", backgroundColor: "#10b981" },

  footerFixed: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 12,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
    flexDirection: "row",
    gap: 10,
  },
  btn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  btnGhost: { backgroundColor: "#f1f5f9" },
  btnPrimary: { backgroundColor: "#0f37f1" },
  btnText: { color: "white", fontWeight: "800" },
});
