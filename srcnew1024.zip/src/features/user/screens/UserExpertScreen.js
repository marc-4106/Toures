import React, { useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  Animated,
  Platform,
  TouchableWithoutFeedback,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

export default function UserExpertScreen() {
  const navigation = useNavigation();
  const scale = useRef(new Animated.Value(1)).current;

  const goToPreferences = () => navigation.navigate("TravelPreferences");

  const onPressIn = () => {
    Animated.spring(scale, { toValue: 0.9, useNativeDriver: true }).start();
  };
  const onPressOut = () => {
    Animated.spring(scale, { toValue: 1, friction: 3, useNativeDriver: true }).start(() => {
      goToPreferences();
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Explore with Toures ✈️</Text>
      <Text style={styles.sub}>Plan your next adventure — tap the Toures icon for smart, personalized recommendations.</Text>

      {/* Floating static button */}
      <Animated.View
        style={[
          styles.pinWrapper,
          {
            transform: [{ scale }],
          },
        ]}
      >
        <TouchableWithoutFeedback onPressIn={onPressIn} onPressOut={onPressOut}>
          <View style={styles.buttonWrapper}>
            <View style={styles.shadowGlow} />
            <Image
              source={require("../../../../assets/login/WhiteToures.png")}
              style={styles.pinImage}
              resizeMode="contain"
            />
          </View>
        </TouchableWithoutFeedback>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8f9fa", padding: 16 },
  heading: { fontSize: 24, fontWeight: "800", color: "#0f172a", marginTop: 8 },
  sub: { marginTop: 6, color: "#475569" },

  // fixed position
  pinWrapper: {
    position: "absolute",
    right: 15,
    bottom: 60,
    width: 80,
    height: 80,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonWrapper: {
    alignItems: "center",
    justifyContent: "center",
  },

  // soft glow shadow for button-like look
  shadowGlow: {
    position: "absolute",
    width: 65,
    height: 60,
    borderRadius: 45,
    backgroundColor: "rgba(15, 55, 241, 0.18)",
    ...Platform.select({
      ios: {
        shadowColor: "#0f37f1",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.4,
        shadowRadius: 10,
      },
      android: {
        elevation: 12,
      },
    }),
  },

  pinImage: {
    width: 60,
    height: 60,
  },
});
