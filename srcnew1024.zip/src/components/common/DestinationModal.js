// src/components/common/DestinationModal.js
import React, { useState, useEffect } from "react";
import {
  Modal,
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  StyleSheet,
  ScrollView,
  Switch,
} from "react-native";

const toKey = (s) => String(s).toLowerCase().trim();

// allow only digits and a single dot (no other chars)
const sanitizeMoney = (s) =>
  String(s || "")
    .replace(/[^\d.]/g, "")
    .replace(/(\..*)\./g, "$1");

// coords allow minus and one dot
const sanitizeCoord = (s) =>
  String(s || "")
    .replace(/[^-\d.]/g, "")
    .replace(/(.*-.*)-/g, "$1") // keep only first minus
    .replace(/(\..*)\./g, "$1"); // keep only first dot

const TAG_OPTIONS = [
  "shopping", "adventure", "activity", "relaxation", "nature", "beach",
  "indoor", "outdoor", "night", "day", "culture",
  "family_friendly", "scenic", "history", "foodie", "photography",
  "budget", "premium", "city", "park", "lodging"
];

export default function DestinationModal({
  visible,
  onClose,
  onSave,
  form,
  setForm,
  isLoading,
  error,
  editId,
  kindOptions = ["Hotel", "Restaurant", "Resort", "Mall", "Heritage", "Pasalubong Centers"],
}) {
  const [localKind, setLocalKind] = useState(form.kind ? form.kind : "");

  useEffect(() => {
    setLocalKind(form.kind ? toKey(form.kind) : "");
  }, [form.kind]);

  const setKindLower = (label) => {
    const val = toKey(label);
    setLocalKind(val);
    setForm((f) => ({ ...f, kind: val }));
  };

  const toggleTag = (key) => {
    const k = toKey(key);
    setForm((f) => {
      const current = new Set(f.tags || []);
      if (current.has(k)) current.delete(k);
      else current.add(k);
      return { ...f, tags: Array.from(current) };
    });
  };

  const isTagChecked = (key) => (form.tags || []).includes(toKey(key));

  const field = (label, children, style = {}) => (
    <View style={style}>
      <Text style={styles.label}>{label}</Text>
      {children}
    </View>
  );

  const setDeep = (path, value) => {
    setForm((prev) => {
      const next = { ...prev };
      let cur = next;
      for (let i = 0; i < path.length - 1; i++) {
        const k = path[i];
        cur[k] = cur[k] ?? {};
        cur = cur[k];
      }
      cur[path[path.length - 1]] = value;
      return next;
    });
  };

  const showLodging = true;
  const showMealPlan = true;
  const showDayUse = true;

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <Pressable style={styles.closeBtn} onPress={onClose}>
            <Text style={styles.closeBtnText}>×</Text>
          </Pressable>

          <Text style={styles.title}>{editId ? "Edit Destination" : "Add Destination"}</Text>
          {error ? <Text style={styles.error}>{error}</Text> : null}

          <ScrollView
            contentContainerStyle={{ paddingBottom: 115 }}
            showsVerticalScrollIndicator={false}
          >
            {field(
              "Name",
              <TextInput
                placeholder="Place name"
                placeholderTextColor="#999"
                style={styles.input}
                value={form.name}
                onChangeText={(text) => setForm((f) => ({ ...f, name: text }))}
              />,
              { marginBottom: 6 }
            )}

            {field(
              "Description",
              <TextInput
                placeholder="Short description"
                placeholderTextColor="#999"
                style={[styles.input, { minHeight: 80 }]}
                value={form.description}
                onChangeText={(text) => setForm((f) => ({ ...f, description: text }))}
                multiline
              />,
              { marginBottom: 6 }
            )}

            {field(
              "Image URL",
              <TextInput
                placeholder="https://…"
                placeholderTextColor="#999"
                style={styles.input}
                autoCapitalize="none"
                value={form.imageUrl}
                onChangeText={(text) => setForm((f) => ({ ...f, imageUrl: text }))}
              />,
              { marginBottom: 6 }
            )}

            {field(
              "City / Municipality",
              <TextInput
                placeholder="e.g., Dumaguete City or Valencia"
                placeholderTextColor="#999"
                style={styles.input}
                value={form.cityOrMunicipality}
                onChangeText={(text) => setForm((f) => ({ ...f, cityOrMunicipality: text }))}
              />,
              { marginBottom: 6 }
            )}

            {/* Coordinates */}
            {field(
              "Coordinates (latitude, longitude)",
              <View style={{ flexDirection: "row", gap: 8 }}>
                <TextInput
                  placeholder="10.6596"
                  placeholderTextColor="#999"
                  style={[styles.input, { flex: 1 }]}
                  keyboardType="decimal-pad"
                  value={String(form?.Coordinates?.latitude ?? "")}
                  onChangeText={(text) =>
                    setForm((f) => ({
                      ...f,
                      Coordinates: {
                        ...f.Coordinates,
                        latitude: sanitizeCoord(text),
                      },
                    }))
                  }
                />
                <TextInput
                  placeholder="122.9397"
                  placeholderTextColor="#999"
                  style={[styles.input, { flex: 1 }]}
                  keyboardType="decimal-pad"
                  value={String(form?.Coordinates?.longitude ?? "")}
                  onChangeText={(text) =>
                    setForm((f) => ({
                      ...f,
                      Coordinates: {
                        ...f.Coordinates,
                        longitude: sanitizeCoord(text),
                      },
                    }))
                  }
                />
              </View>,
              { marginBottom: 6 }
            )}

            {/* Kind */}
            <Text style={[styles.label, { marginTop: 4 }]}>Kind (pick one)</Text>
            <View style={[styles.grid, { marginBottom: 6 }]}>
              {kindOptions.map((label) => {
                const val = toKey(label);
                const selected = (form.kind || localKind) === val;
                return (
                  <Pressable
                    key={label}
                    onPress={() => setKindLower(label)}
                    style={[
                      styles.checkRow,
                      {
                        borderColor: selected ? "#0f37f1" : "#e5e7eb",
                        backgroundColor: selected ? "#dbeafe" : "transparent",
                      },
                    ]}
                  >
                    <View style={[styles.checkbox, selected && styles.checkboxCheckedBlue]} />
                    <Text
                      style={[
                        styles.checkLabel,
                        { color: selected ? "#0f37f1" : "#111" },
                      ]}
                    >
                      {label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            {/* Tags */}
            <Text style={styles.label}>Tags (select all that apply)</Text>
            <View style={[styles.grid, { marginBottom: 6 }]}>
              {TAG_OPTIONS.map((label) => {
                const checked = isTagChecked(label);
                return (
                  <Pressable
                    key={label}
                    onPress={() => toggleTag(label)}
                    style={[
                      styles.checkRow,
                      {
                        borderColor: checked ? "#10b981" : "#e5e7eb",
                        backgroundColor: checked ? "#d1fae5" : "transparent",
                      },
                    ]}
                  >
                    <View style={[styles.checkbox, checked && styles.checkboxCheckedGreen]} />
                    <Text
                      style={[
                        styles.checkLabel,
                        { color: checked ? "#065f46" : "#111" },
                      ]}
                    >
                      {label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            {/* Contact */}
            {field(
              "Contact Email",
              <TextInput
                placeholder="name@example.com"
                placeholderTextColor="#999"
                style={styles.input}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                textContentType="emailAddress"
                value={form?.contact?.email || ""}
                onChangeText={(text) =>
                  setForm((f) => ({ ...f, contact: { ...f.contact, email: text } }))
                }
              />,
              { marginBottom: 6 }
            )}

            {field(
              "Contact Phone",
              <TextInput
                placeholder="(034) 123-4567 or 0917 123 4567"
                placeholderTextColor="#999"
                style={styles.input}
                keyboardType="phone-pad"
                autoComplete="tel"
                textContentType="telephoneNumber"
                value={form?.contact?.phoneRaw || ""}
                onChangeText={(text) =>
                  setForm((f) => ({ ...f, contact: { ...f.contact, phoneRaw: text } }))
                }
              />,
              { marginBottom: 6 }
            )}

            {/* Pricing */}
            {(showLodging || showMealPlan || showDayUse) && (
              <Text style={[styles.label, { marginTop: 4, marginBottom: 6 }]}>Pricing</Text>
            )}

            {/* Lodging */}
            {showLodging && (
              <View style={{ marginBottom: 6 }}>
                <Text style={styles.subLabel}>Lodging (per night)</Text>
                <TextInput
                  placeholder="e.g., 2800"
                  placeholderTextColor="#999"
                  style={styles.input}
                  keyboardType="decimal-pad"
                  value={sanitizeMoney(form?.pricing?.lodging?.base ?? "")}
                  onChangeText={(text) =>
                    setDeep(["pricing", "lodging", "base"], sanitizeMoney(text))
                  }
                />
              </View>
            )}

            {/* Meal Plan */}
            {showMealPlan && (
              <>
                <Text style={[styles.subLabel, { marginTop: 4 }]}>Meal Plan</Text>
                <View style={styles.switchRow}>
                  <Text style={styles.switchText}>Breakfast Included</Text>
                  <Switch
                    value={!!form?.pricing?.mealPlan?.breakfastIncluded}
                    onValueChange={(v) =>
                      setDeep(["pricing", "mealPlan", "breakfastIncluded"], v)
                    }
                  />
                </View>
                <View style={styles.switchRow}>
                  <Text style={styles.switchText}>Lunch Included</Text>
                  <Switch
                    value={!!form?.pricing?.mealPlan?.lunchIncluded}
                    onValueChange={(v) =>
                      setDeep(["pricing", "mealPlan", "lunchIncluded"], v)
                    }
                  />
                </View>
                <View style={[styles.switchRow, { marginBottom: 6 }]}>
                  <Text style={styles.switchText}>Dinner Included</Text>
                  <Switch
                    value={!!form?.pricing?.mealPlan?.dinnerIncluded}
                    onValueChange={(v) =>
                      setDeep(["pricing", "mealPlan", "dinnerIncluded"], v)
                    }
                  />
                </View>

                {field(
                  "À-la-carte Default (₱)",
                  <TextInput
                    placeholder="e.g., 300"
                    placeholderTextColor="#999"
                    style={styles.input}
                    keyboardType="decimal-pad"
                    value={sanitizeMoney(form?.pricing?.mealPlan?.aLaCarteDefault ?? "300")}
                    onChangeText={(text) =>
                      setDeep(["pricing", "mealPlan", "aLaCarteDefault"], sanitizeMoney(text))
                    }
                  />,
                  { marginBottom: 6 }
                )}
              </>
            )}

            {/* Day Use */}
            {showDayUse && (
              <View style={{ marginBottom: 6 }}>
                <Text style={styles.subLabel}>Day Use (Resort)</Text>
                <TextInput
                  placeholder="Day pass price, e.g., 300"
                  placeholderTextColor="#999"
                  style={styles.input}
                  keyboardType="decimal-pad"
                  value={sanitizeMoney(form?.pricing?.dayUse?.dayPassPrice ?? "")}
                  onChangeText={(text) =>
                    setDeep(["pricing", "dayUse", "dayPassPrice"], sanitizeMoney(text))
                  }
                />
              </View>
            )}

              {/* ✅ New: Activities List */}
              <Text style={[styles.label, { marginTop: 6 }]}>List of Activities</Text>

              {(form.activities || []).map((activity, idx) => (
                <View key={idx} style={styles.activityRow}>
                  <TextInput
                    placeholder={`Activity ${idx + 1}`}
                    placeholderTextColor="#999"
                    style={[styles.input, { flex: 1, paddingRight: 36 }]} // padding for icon space
                    value={activity}
                    onChangeText={(text) =>
                      setForm((f) => {
                        const next = [...(f.activities || [])];
                        next[idx] = text;
                        return { ...f, activities: next };
                      })
                    }
                  />
                  <Pressable
                    onPress={() =>
                      setForm((f) => ({
                        ...f,
                        activities: (f.activities || []).filter((_, i) => i !== idx),
                      }))
                    }
                    style={styles.removeIconBtn}
                  >
                    <Text style={styles.removeIconText}>×</Text>
                  </Pressable>
                </View>
              ))}

              <Pressable
                onPress={() =>
                  setForm((f) => ({
                    ...f,
                    activities: [...(f.activities || []), ""],
                  }))
                }
                style={styles.addActivityBtn}
              >
                <Text style={styles.addActivityText}>+ Add Activity</Text>
              </Pressable>


            <Pressable
              onPress={() =>
                setForm((f) => ({
                  ...f,
                  activities: [...(f.activities || []), ""],
                }))
              }
              style={styles.addBtn}
            >
              <Text style={{ color: "#000000ff", fontWeight: "700" }}>+ Add Activity</Text>
            </Pressable>

            {/* Featured flag */}
            <View style={{ flexDirection: "row", gap: 8, marginTop: 4, marginBottom: 8 }}>
              <Pressable
                onPress={() => setForm((f) => ({ ...f, isFeatured: !f.isFeatured }))}
                style={[
                  styles.pill,
                  { borderColor: form.isFeatured ? "#0f37f1" : "#ccc" },
                ]}
              >
                <Text style={{ color: form.isFeatured ? "#0f37f1" : "#333" }}>
                  {form.isFeatured ? "★ Featured" : "☆ Not featured"}
                </Text>
              </Pressable>
            </View>
          </ScrollView>

          {/* Footer */}
          <View style={styles.footer}>
            <Pressable onPress={onClose} style={[styles.btn, styles.btnCancel]}>
              <Text style={styles.btnText}>Cancel</Text>
            </Pressable>
            <Pressable
              onPress={onSave}
              style={[styles.btn, styles.btnSave]}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.btnText}>
                  {editId ? "Save Changes" : "Create"}
                </Text>
              )}
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.35)", justifyContent: "center" },
  sheet: {
    backgroundColor: "white",
    padding: 16,
    paddingTop: 5,
    borderRadius: 16,
    maxHeight: "92%",
    width: "80%",
    maxWidth: 800,
    alignSelf: "center",
  },
  closeBtn: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#961515ff",
    alignItems: "center",
    justifyContent: "center",
  },
  closeBtnText: { fontSize: 22, lineHeight: 30, color: "#ffffffff", fontWeight: "800" },

  title: { fontSize: 18, fontWeight: "700", marginBottom: 10, paddingRight: 36 },
  label: { fontWeight: "600", marginBottom: 4 },
  subLabel: { fontWeight: "700", marginTop: 4, marginBottom: 4, color: "#0f172a" },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, padding: 10, color: "#111" },
  error: { backgroundColor: "#fee2e2", color: "#991b1b", padding: 8, borderRadius: 8, marginBottom: 10 },

  grid: { flexDirection: "row", flexWrap: "wrap", gap: 4 },
  checkRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  checkbox: {
    width: 14,
    height: 14,
    borderWidth: 2,
    borderColor: "#9ca3af",
    borderRadius: 3,
    backgroundColor: "transparent",
    marginRight: 6,
  },
  checkboxCheckedBlue: { borderColor: "#0f37f1", backgroundColor: "#0f37f1" },
  checkboxCheckedGreen: { borderColor: "#10b981", backgroundColor: "#10b981" },
  checkLabel: { fontSize: 14 },

  pill: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
  },

  switchRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 4,
  },
  switchText: { fontWeight: "600", color: "#0f172a" },

  footer: {
    position:
 "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 12,
    backgroundColor: "white",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
    flexDirection: "row",
    gap: 10,
  },
  btn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  btnCancel: { backgroundColor: "#ef4444" },
  btnSave: { backgroundColor: "#0f37f1" },
  btnText: { color: "white", fontWeight: "700" },
  activityRow: {
  flexDirection: "row",
  alignItems: "center",
  marginBottom: 6,
  position: "relative",
},

removeIconBtn: {
  position: "absolute",
  right: 10,
  top: "50%",
  transform: [{ translateY: -10 }],
  width: 24,
  height: 24,
  borderRadius: 12,
  alignItems: "center",
  justifyContent: "center",
  backgroundColor: "#ef4444",
},

removeIconText: {
  color: "white",
  fontSize: 16,
  fontWeight: "800",
  lineHeight: 18,
},

addActivityBtn: {
  backgroundColor: "#0f37f1",
  borderRadius: 10,
  paddingVertical: 10,
  alignItems: "center",
  marginBottom: 10,
},

addActivityText: {
  color: "white",
  fontWeight: "700",
  fontSize: 14,
},

});