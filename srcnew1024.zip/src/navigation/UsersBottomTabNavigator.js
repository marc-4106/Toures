import React, { useCallback } from 'react';
import { Alert, BackHandler, Platform, Text, View, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { signOut } from 'firebase/auth';
import { auth } from '../services/firebaseConfig'; // ✅ same instance App.js uses

import HomeScreen from '../features/user/screens/UserHomeScreen';
import MyListScreen from '../features/user/screens/UserMyListScreen';
import ExploreScreen from '../features/user/screens/UserExploreScreen';
import ProfileScreen from '../features/user/screens/UserProfileScreen';
import ExpertScreen from '../features/user/screens/UserExpertScreen';

const Tab = createBottomTabNavigator();

const createTabBarIcon = (name, focused) => (
  <Ionicons
    name={focused ? name : `${name}-outline`}
    size={focused ? 30 : 26}
    color={focused ? '#1badf9' : 'gray'}
  />
);

const createTabBarLabel = (label, focused) => (
  <Text style={{ color: focused ? '#1badf9' : 'gray', fontSize: 12 }}>{label}</Text>
);

const UsersBottomTabNavigator = () => {
  const navigation = useNavigation();

  // 🔒 Intercept Android hardware back at the tab root
  useFocusEffect(
    useCallback(() => {
      if (Platform.OS !== 'android') return;

      const onBackPress = () => {
        Alert.alert(
          'Logout?',
          'Do you want to logout and return to the Welcome screen?',
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Logout',
              style: 'destructive',
              onPress: async () => {
                try {
                  // DEBUG: show current user before sign out
                  // console.log('Before signOut, currentUser:', auth.currentUser?.uid);

                  await signOut(auth);

                  // DEBUG: show after sign out (should be null)
                  // console.log('After signOut, currentUser:', auth.currentUser);

                  // Normally App.js onAuthStateChanged will re-render to welcome.
                  // Fallback: force-reset navigation to a top-level unauth route if needed.
                  // Replace 'Welcome' with your unauth initial route if you named it differently.
                  navigation.reset({
                    index: 0,
                    routes: [{ name: 'Welcome' }], // <-- change if your unauth route has a different name
                  });
                } catch (e) {
                  console.warn('Sign out failed:', e);
                  Alert.alert('Logout failed', e?.message ?? 'Please try again.');
                }
              },
            },
          ]
        );
        return true; // prevent default back navigation
      };

      BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => BackHandler.removeEventListener('hardwareBackPress', onBackPress);
    }, [navigation])
  );

  return (
    <SafeAreaProvider>
      <Tab.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
          tabBarHideOnKeyboard: true, // helps with covered inputs
          tabBarStyle: {
            position: 'absolute',
            height: 55,
            borderTopWidth: 0,
            elevation: 0,
            backgroundColor: '#fff',
            overflow: 'visible',
            paddingBottom: 5,
          },
        }}
      >
        <Tab.Screen
          name="Home"
          component={HomeScreen}
          options={{
            tabBarIcon: ({ focused }) => createTabBarIcon('home', focused),
            tabBarLabel: ({ focused }) => createTabBarLabel('Home', focused),
          }}
        />

        <Tab.Screen
          name="Events"
          component={MyListScreen}
          options={{
            tabBarIcon: ({ focused }) => createTabBarIcon('calendar', focused),
            tabBarLabel: ({ focused }) => createTabBarLabel('Events', focused),
          }}
        />

        <Tab.Screen
          name="FuzzyPlan"
          component={ExpertScreen}
          options={{
            tabBarLabel: () => null,
            tabBarIcon: ({ focused }) => (
              <View style={styles.fabWrapper} accessible accessibilityLabel="Fuzzy Plan">
                <View style={[styles.fabButton, { borderColor: focused ? '#1badf9' : 'gray' }]}>
                  <Ionicons
                    name={focused ? 'bulb' : 'bulb-outline'}
                    size={28}
                    color={focused ? '#1badf9' : 'gray'}
                  />
                </View>
                <Text style={[styles.fabLabel, { color: focused ? '#1badf9' : 'gray' }]}>
                  Fuzzy Plan
                </Text>
              </View>
            ),
          }}
        />

        <Tab.Screen
          name="Explore"
          component={ExploreScreen}
          options={{
            tabBarIcon: ({ focused }) => createTabBarIcon('search', focused),
            tabBarLabel: ({ focused }) => createTabBarLabel('Explore', focused),
          }}
        />

        <Tab.Screen
          name="Profile"
          component={ProfileScreen}
          options={{
            tabBarIcon: ({ focused }) => createTabBarIcon('person', focused),
            tabBarLabel: ({ focused }) => createTabBarLabel('Profile', focused),
          }}
        />
      </Tab.Navigator>
    </SafeAreaProvider>
  );
};

export default UsersBottomTabNavigator;

const styles = StyleSheet.create({
  fabWrapper: {
    position: 'absolute',
    top: -30,
    justifyContent: 'center',
    alignItems: 'center',
    width: 70,
  },
  fabButton: {
    width: 60,
    height: 60,
    backgroundColor: '#fff',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#1badf9',
    elevation: 6,
    shadowColor: '#1badf9',
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
  },
  fabLabel: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '500',
  },
});
