import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../../../services/firebaseConfig";

export async function saveItinerary(userId, preferences, buildPlan) {
  try {
    const docRef = await addDoc(collection(db, "itineraries"), {
      userId,
      preferences,
      buildPlan,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    console.log("Saved itinerary ID:", docRef.id);
    return docRef.id;
  } catch (error) {
    console.error("Error saving itinerary:", error);
    throw error;
  }
}


