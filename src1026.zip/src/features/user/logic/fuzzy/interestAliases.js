// interestAliases.js
// Unified alias mapping for fuzzy recommendation system.
// Connects user interests ↔ destination tags ↔ kinds

export const INTEREST_TAG_ALIASES = {
  // --- CULTURE & HISTORY ---
  culture: [
    "heritage",
    "museum",
    "art_gallery",
    "local_crafts",
    "religious_site",
    "architecture",
    "photography",
    "history",
    "city",
  ],
  heritage: ["culture", "history", "museum", "architecture"],
  history: ["heritage", "museum", "culture", "religious_site"],
  museum: ["heritage", "culture", "art_gallery", "education"],
  art_gallery: ["museum", "culture", "photography", "art", "heritage"],
  local_crafts: ["pasalubong", "souvenir", "handicraft", "market", "culture"],
  religious_site: ["church", "shrine", "heritage", "culture"],

  // --- NATURE & OUTDOORS ---
  nature: [
    "park",
    "mountain",
    "waterfall",
    "forest",
    "beach",
    "outdoor",
    "eco_resort",
    "scenic_view",
  ],
  park: ["nature", "outdoor", "family_friendly", "relaxation"],
  mountain: ["nature", "hiking", "adventure", "outdoor"],
  waterfall: ["nature", "adventure", "scenic_view"],
  beach: ["resort", "nature", "island", "relaxation", "adventure"],
  island: ["beach", "resort", "nature", "snorkeling", "diving"],
  outdoor: ["nature", "adventure", "camping", "trekking", "scenic_view"],
  eco_resort: ["resort", "nature", "relaxation", "family_friendly"],

  // --- ADVENTURE & ACTIVITIES ---
  adventure: [
    "activity",
    "outdoor",
    "thrills",
    "hiking",
    "surfing",
    "snorkeling",
    "diving",
    "zipline",
    "camping",
  ],
  activity: ["adventure", "outdoor", "thrills", "group_event"],
  hiking: ["mountain", "nature", "trekking", "adventure"],
  snorkeling: ["beach", "island", "diving", "adventure"],
  diving: ["island", "adventure", "water_activity"],
  camping: ["outdoor", "nature", "group_event"],
  zipline: ["adventure", "thrills", "park"],
  surfing: ["beach", "adventure", "nature"],
  thrills: ["adventure", "activity", "park"],
  group_event: ["activity", "family_friendly", "team_building"],

  // --- FOOD & CUISINE ---
  foodie: [
    "restaurant",
    "local_cuisine",
    "seafood",
    "buffet",
    "street_food",
    "fine_dining",
    "cafe",
    "pasalubong_center",
    "desserts",
  ],
  restaurant: ["foodie", "local_cuisine", "buffet", "seafood"],
  local_cuisine: ["restaurant", "foodie", "street_food", "pasalubong_center"],
  seafood: ["restaurant", "foodie", "beach", "buffet"],
  buffet: ["restaurant", "foodie", "hotel"],
  street_food: ["local_cuisine", "foodie", "market"],
  fine_dining: ["restaurant", "foodie", "luxury_hotel"],
  cafe: ["foodie", "desserts", "romantic_spot", "city"],
  desserts: ["cafe", "foodie", "local_cuisine"],

  // --- SHOPPING & URBAN ---
  shopping: [
    "mall",
    "market",
    "souvenir",
    "pasalubong_center",
    "city",
    "urban",
    "foodie",
  ],
  mall: ["shopping", "city", "restaurant", "indoor"],
  market: ["shopping", "local_crafts", "street_food", "souvenir"],
  pasalubong_center: ["shopping", "souvenir", "local_crafts", "foodie"],
  souvenir: ["shopping", "local_crafts", "pasalubong_center"],
  city: ["shopping", "nightlife", "foodie", "culture"],
  urban: ["mall", "shopping", "city", "restaurant"],

  // --- RELAXATION & WELLNESS ---
  relaxation: [
    "resort",
    "spa",
    "hotel",
    "beach_resort",
    "quiet_place",
    "wellness",
    "romantic_spot",
    "eco_resort",
  ],
  resort: ["relaxation", "beach", "family_friendly", "adventure"],
  spa: ["relaxation", "wellness", "hotel"],
  romantic_spot: ["relaxation", "beach", "cafe", "hotel"],
  wellness: ["spa", "retreat", "resort"],
  retreat: ["wellness", "nature", "relaxation"],
  quiet_place: ["relaxation", "nature", "scenic_view"],
  beach_resort: ["resort", "beach", "relaxation"],

  // --- FAMILY / GROUP TRAVEL ---
  family_friendly: [
    "park",
    "resort",
    "pool",
    "amusement",
    "picnic",
    "kids_activity",
  ],
  kids_activity: ["family_friendly", "amusement", "park"],
  amusement: ["family_friendly", "park", "activity"],
  pool: ["resort", "family_friendly"],
  picnic: ["park", "outdoor", "family_friendly"],

  // --- LODGING / ACCOMMODATION ---
  lodging: [
    "hotel",
    "resort",
    "villa",
    "transient_house",
    "homestay",
    "bed_and_breakfast",
  ],
  hotel: ["lodging", "relaxation", "luxury_hotel", "budget_inn"],
  luxury_hotel: ["hotel", "premium", "spa"],
  budget_inn: ["hotel", "budget", "lodging"],
  villa: ["lodging", "resort", "romantic_spot"],
  homestay: ["lodging", "budget", "local_experience"],
  transient_house: ["lodging", "budget", "group_event"],
  bed_and_breakfast: ["lodging", "foodie", "relaxation"],

  // --- OTHER / META TAGS ---
  budget: ["hotel", "budget_inn", "restaurant", "market"],
  premium: ["luxury_hotel", "fine_dining", "resort"],
  hidden_gem: ["scenic_view", "quiet_place", "nature"],
  must_visit: ["heritage", "beach", "park"],
};
