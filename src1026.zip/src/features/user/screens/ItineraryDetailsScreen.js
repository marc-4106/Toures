import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { collection, getDoc, doc } from "firebase/firestore";
import { db } from "../../../services/firebaseConfig";

export default function ItineraryDetailsScreen({ route }) {
  const { itinerary } = route.params || {};
  const [days, setDays] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch full destination data (activities[]) from Firestore
  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const enrichedDays = [];

        for (const day of itinerary.days || []) {
          const newDay = { ...day };

          const fetchDestination = async (item) => {
            if (!item?.id) return null;
            const ref = doc(db, "destinations", item.id);
            const snap = await getDoc(ref);
            if (snap.exists()) {
              return { ...item, ...snap.data() };
            }
            return item;
          };

          newDay.breakfast = await fetchDestination(day.breakfast);
          newDay.lunch = await fetchDestination(day.lunch);
          newDay.dinner = await fetchDestination(day.dinner);

          const fullActs = [];
          for (const act of day.activities || []) {
            const ref = doc(db, "destinations", act.id);
            const snap = await getDoc(ref);
            if (snap.exists()) fullActs.push({ ...act, ...snap.data() });
          }
          newDay.activities = fullActs;

          enrichedDays.push(newDay);
        }

        setDays(enrichedDays);
      } catch (err) {
        console.error("Failed to load activities:", err);
        Alert.alert("Error", "Unable to load itinerary details.");
      } finally {
        setLoading(false);
      }
    };

    if (itinerary?.days) fetchActivities();
  }, [itinerary]);

  const renderActivityGroup = (acts = []) => {
    if (!acts.length)
      return <Text style={styles.noActivity}>No activities listed.</Text>;

    return acts.map((act, i) => (
      <View key={i} style={{ marginBottom: 8 }}>
        <Text style={styles.destTitle}>• {act.name || act.title}</Text>
        {(act.activities || []).map((a, idx) => (
          <Text key={idx} style={styles.activityText}>
            - {a}
          </Text>
        ))}
      </View>
    ));
  };

  if (loading)
    return (
      <View style={styles.centered}>
        <ActivityIndicator color="#0f37f1" size="large" />
      </View>
    );

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Header Info */}
      <Text style={styles.headerText}>
        🏨 Stay at: {itinerary.hotel?.primary?.name || "N/A"}
      </Text>

      {days.map((day, idx) => (
        <View key={idx} style={styles.dayCard}>
          <Text style={styles.dayTitle}>📅 Day {day.day}</Text>

          {/* Morning */}
          <Text style={styles.timeLabel}>🌅 Morning</Text>
          <Text style={styles.mealText}>
            - Breakfast: {day.breakfast?.name || "—"}
          </Text>
          <Text style={styles.subLabel}>Activities:</Text>
          {renderActivityGroup(
            day.activities?.filter((a) =>
              (a.timeOfDay || "morning").includes("morning")
            )
          )}

          {/* Afternoon */}
          <Text style={styles.timeLabel}>🌞 Afternoon</Text>
          <Text style={styles.mealText}>
            - Lunch: {day.lunch?.name || "—"}
          </Text>
          <Text style={styles.subLabel}>Activities:</Text>
          {renderActivityGroup(
            day.activities?.filter((a) =>
              (a.timeOfDay || "afternoon").includes("afternoon")
            )
          )}

          {/* Evening */}
          <Text style={styles.timeLabel}>🌙 Evening</Text>
          <Text style={styles.mealText}>
            - Dinner: {day.dinner?.name || "—"}
          </Text>
          <Text style={styles.subLabel}>Activities:</Text>
          {renderActivityGroup(
            day.activities?.filter((a) =>
              (a.timeOfDay || "evening").includes("evening")
            )
          )}
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 50,
    backgroundColor: "#f8fafc",
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  headerText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#0f172a",
    marginBottom: 12,
  },
  dayCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  dayTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#0f172a",
    marginBottom: 8,
  },
  timeLabel: {
    fontSize: 15,
    fontWeight: "700",
    color: "#0f37f1",
    marginTop: 6,
  },
  mealText: {
    fontSize: 14,
    color: "#1e293b",
    marginLeft: 10,
    marginTop: 2,
  },
  subLabel: {
    fontSize: 13,
    color: "#475569",
    marginLeft: 10,
    marginTop: 4,
    marginBottom: 2,
  },
  destTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#334155",
    marginLeft: 20,
  },
  activityText: {
    fontSize: 13,
    color: "#475569",
    marginLeft: 36,
  },
  noActivity: {
    fontSize: 12,
    color: "#9ca3af",
    marginLeft: 20,
    fontStyle: "italic",
  },
});
