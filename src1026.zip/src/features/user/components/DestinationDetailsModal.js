// src/features/user/components/DestinationDetailsModal.js
import React, { useMemo } from "react";
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { haversineKm, formatKm } from "../../recommender/distance";
import { navigateToExplore } from "../../../utils/navigateToExplore";

export default function DestinationDetailsModal({
  visible,
  onClose,
  destination,
  userLocation,
  onGetDirections, // optional callback
}) {
  if (!visible || !destination) return null;

  const km = useMemo(() => {
    if (!userLocation) return null;
    const lat = destination?.Coordinates?.latitude;
    const lng = destination?.Coordinates?.longitude;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return haversineKm(userLocation.latitude, userLocation.longitude, lat, lng);
  }, [destination, userLocation]);

  const kindPretty =
    (destination?.kind || "")
      ? (destination.kind.charAt(0).toUpperCase() + destination.kind.slice(1))
      : "—";

  const idealCostPretty =
    typeof destination?.idealCost === "number"
      ? `₱${destination.idealCost.toLocaleString()}`
      : destination?.idealCost
      ? `₱${Number(destination.idealCost).toLocaleString()}`
      : "—";

  const contactEmail = destination?.contact?.email || "";
  const contactPhone = destination?.contact?.phoneRaw || destination?.contact?.phone || "";

  const handleCall = () => {
    if (!contactPhone) return;
    Linking.openURL(`tel:${contactPhone}`).catch(() => {});
  };

  const handleEmail = () => {
    if (!contactEmail) return;
    Linking.openURL(`mailto:${contactEmail}`).catch(() => {});
  };

  const handleGetDirections = () => {
    if (onGetDirections) {
      onGetDirections(destination);
      return;
    }
    // fallback: use navigation stored on the model (we attached __nav in the list)
    if (destination?.__nav) {
      navigateToExplore(destination.__nav, destination, { showRoute: true });
      return;
    }
    // last resort just close
    onClose?.();
  };

  return (
    <View style={styles.overlay} pointerEvents="auto">
      <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={onClose} />
      <View style={styles.sheet}>
        {/* Title */}
        <Text style={styles.title} numberOfLines={2}>
          {destination?.name || "Destination"}
        </Text>

        {/* Kind (no label) */}
       <Text style={styles.kindText}>{kindPretty}</Text>

        {/* City / Municipality */}
        <Text style={styles.meta}>City / Municipality: {destination?.cityOrMunicipality || "—"}</Text>

        {/* Distance */}
        <Text style={styles.meta}>Distance: {km == null ? "—" : formatKm(km)}</Text>

  
        {/* Description (scrollable if long) */}
        <ScrollView
          style={styles.descScroll}
          contentContainerStyle={{ paddingBottom: 8 }}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.sectionLabel}>Description</Text>
          <Text style={styles.descriptionText}>
            {destination?.description || "No description."}
          </Text>

          {/* Contact section */}
          {(contactPhone || contactEmail) ? (
            <>
              <Text style={[styles.sectionLabel, { marginTop: 16 }]}>Contact</Text>
              {contactPhone ? (
                <TouchableOpacity style={styles.contactRow} onPress={handleCall}>
                  <Ionicons name="call-outline" size={18} color="#0f37f1" />
                  <Text style={styles.contactText}>{contactPhone}</Text>
                </TouchableOpacity>
              ) : null}
              {contactEmail ? (
                <TouchableOpacity style={styles.contactRow} onPress={handleEmail}>
                  <Ionicons name="mail-outline" size={18} color="#0f37f1" />
                  <Text style={styles.contactText}>{contactEmail}</Text>
                </TouchableOpacity>
              ) : null}
            </>
          ) : null}
        </ScrollView>

        {/* Primary action */}
        <TouchableOpacity style={styles.primaryBtn} onPress={handleGetDirections}>
          <Ionicons name="navigate-outline" size={18} color="#fff" />
          <Text style={styles.primaryBtnText}>Get Direction</Text>
        </TouchableOpacity>

        {/* X button */}
        <TouchableOpacity style={styles.xIcon} onPress={onClose}>
          <Text style={styles.xText}>✕</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 55, zIndex: 999 },
  backdrop: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.5)" },
  sheet: {
    position: "absolute",
    bottom: 0,
    left: 0, right: 0,
    backgroundColor: "#fff",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
    paddingBottom: 24,
  },

  title: { fontSize: 20, fontWeight: "800", color: "#0f172a" },
  kindText: { marginTop: 2, color: "#0f172a", fontWeight: "700" },
  meta: { marginTop: 6, color: "#0f172a", fontWeight: "600" },

  sectionLabel: { color: "#64748b", fontWeight: "700", marginBottom: 6 },
  descScroll: { maxHeight: 360, marginTop: 12 },
  descriptionText: { color: "#0f172a", lineHeight: 20 },

  contactRow: {
    marginTop: 6,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  contactText: { color: "#0f37f1", fontWeight: "700" },

  primaryBtn: {
    marginTop: 14,
    backgroundColor: "#0f37f1",
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    bottom: 10
  },
  primaryBtnText: { color: "#fff", fontWeight: "800" },

  xIcon: { position: "absolute", top: 10, right: 12, padding: 4 },
  xText: { fontSize: 20, fontWeight: "800", color: "#0f172a" },
});
